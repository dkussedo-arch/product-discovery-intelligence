import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json());

  // Initialize Gemini client lazily to avoid crashing if key is not configured on boot
  let aiClient: GoogleGenAI | null = null;

  function getGeminiClient(): GoogleGenAI {
    if (!aiClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error('GEMINI_API_KEY environment variable is not defined.');
      }
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
    return aiClient;
  }

  // API Endpoint: Analyze Product Concept
  app.post('/api/analyze', async (req, res) => {
    try {
      const { name, description, audience, painPoints, industry } = req.body;

      if (!name || !description || !audience || !painPoints || !industry) {
        res.status(400).json({ error: 'Missing required parameters in request body.' });
        return;
      }

      const client = getGeminiClient();

      const prompt = `
        You are a highly analytical B2B and B2C Product Discovery and Market Intelligence analyst.
        Analyze the following product concept and synthesize a full-scale market intelligence dashboard response.
        
        Product Concept Details:
        - Product Name: ${name}
        - Industry/Sector: ${industry}
        - Description: ${description}
        - Target Audience: ${audience}
        - Pain Points: ${painPoints}

        Sizing Guideline:
        Estimate the TAM, SAM, SOM logically in millions of USD (e.g. 500 for $500M) based on standard industry size benchmarks in the ${industry} sector. Provide a concise, highly specific explanation for each tier.

        Competitors Matrix:
        Identify 3 relevant incumbents or alternate solutions (including manual processes or spreadsheets) and detail their market share, strengths, weaknesses, and a precise product differentiator for ${name}.

        SWOT Analysis:
        Provide exactly 3 bullet points for each SWOT segment: Strengths, Weaknesses, Opportunities, and Threats, tailored to the target demographics and market landscape.

        Validation Playbook:
        Create exactly 4 high-value customer discovery questions that the founder should ask real users to test their riskiest assumptions, with clear objectives and follow-up prompts.

        Gaps and Next Steps:
        Synthesize 3 product gaps and 3 next-step validation recommendations.
      `;

      const response = await client.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          systemInstruction: 'You are an objective B2B SaaS research tool. Return strictly compliant JSON schemas only. Never include preamble or surrounding markdown text.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.INTEGER, description: 'Product viability score from 0 to 100.' },
              confidence: { type: Type.INTEGER, description: 'AI estimation confidence score from 0 to 100.' },
              marketSize: {
                type: Type.OBJECT,
                properties: {
                  tam: {
                    type: Type.OBJECT,
                    properties: {
                      value: { type: Type.STRING, description: 'TAM Value string e.g., "$350M"' },
                      numberValue: { type: Type.INTEGER, description: 'TAM value in millions USD' },
                      label: { type: Type.STRING },
                      description: { type: Type.STRING, description: 'Bottom-up TAM details' }
                    },
                    required: ['value', 'numberValue', 'label', 'description']
                  },
                  sam: {
                    type: Type.OBJECT,
                    properties: {
                      value: { type: Type.STRING, description: 'SAM Value string e.g., "$75M"' },
                      numberValue: { type: Type.INTEGER, description: 'SAM value in millions USD' },
                      label: { type: Type.STRING },
                      description: { type: Type.STRING, description: 'Slice targeting this segment' }
                    },
                    required: ['value', 'numberValue', 'label', 'description']
                  },
                  som: {
                    type: Type.OBJECT,
                    properties: {
                      value: { type: Type.STRING, description: 'SOM Value string e.g., "$12M"' },
                      numberValue: { type: Type.INTEGER, description: 'SOM value in millions USD' },
                      label: { type: Type.STRING },
                      description: { type: Type.STRING, description: 'Achievable share in 1-3 years' }
                    },
                    required: ['value', 'numberValue', 'label', 'description']
                  }
                },
                required: ['tam', 'sam', 'som']
              },
              swot: {
                type: Type.OBJECT,
                properties: {
                  strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                  weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
                  opportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
                  threats: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ['strengths', 'weaknesses', 'opportunities', 'threats']
              },
              competitors: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    marketShare: { type: Type.INTEGER },
                    strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                    weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
                    differentiator: { type: Type.STRING }
                  },
                  required: ['name', 'marketShare', 'strengths', 'weaknesses', 'differentiator']
                }
              },
              playbook: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    objective: { type: Type.STRING },
                    targetAudience: { type: Type.STRING },
                    followUp: { type: Type.ARRAY, items: { type: Type.STRING } }
                  },
                  required: ['question', 'objective', 'targetAudience', 'followUp']
                }
              },
              gaps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    area: { type: Type.STRING },
                    description: { type: Type.STRING },
                    opportunityLevel: { type: Type.STRING }
                  },
                  required: ['area', 'description', 'opportunityLevel']
                }
              },
              recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    priority: { type: Type.STRING },
                    timeline: { type: Type.STRING }
                  },
                  required: ['title', 'description', 'priority', 'timeline']
                }
              },
              summary: { type: Type.STRING, description: 'Executive validation summary.' }
            },
            required: ['score', 'confidence', 'marketSize', 'swot', 'competitors', 'playbook', 'gaps', 'recommendations', 'summary']
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error('Gemini API returned an empty response.');
      }

      const cleanJson = responseText.trim();
      const parsedData = JSON.parse(cleanJson);
      
      // Inject productConcept back into the result for completeness
      parsedData.productConcept = { name, description, audience, painPoints, industry };

      res.json(parsedData);
    } catch (error: any) {
      console.error('Server side validation engine error:', error);
      res.status(500).json({ error: error.message || 'Internal Server Error' });
    }
  });

  // Serve static assets or boot Vite Dev Server
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Product Discovery Intelligence server listening on port ${PORT}`);
  });
}

startServer();

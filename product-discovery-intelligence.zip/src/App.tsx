import React, { useState, useEffect } from 'react';
import LandingPage from './landing';
import Dashboard from './dashboard';

export default function App() {
  const [view, setView] = useState<'landing' | 'app'>('landing');

  // Sync state with URL paths on load and when the user interacts
  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname;
      if (path === '/app') {
        setView('app');
      } else {
        setView('landing');
      }
    };

    // Run once on load
    handleLocationChange();

    // Listen to browser popstate actions (back / forward buttons)
    window.addEventListener('popstate', handleLocationChange);
    return () => window.removeEventListener('popstate', handleLocationChange);
  }, []);

  const navigateToApp = () => {
    setView('app');
    window.history.pushState({ view: 'app' }, '', '/app');
  };

  const navigateToHome = () => {
    setView('landing');
    window.history.pushState({ view: 'landing' }, '', '/');
  };

  return (
    <div className="w-full min-h-screen bg-white">
      {view === 'landing' ? (
        <LandingPage onNavigateToApp={navigateToApp} />
      ) : (
        <Dashboard onBackToHome={navigateToHome} />
      )}
    </div>
  );
}

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Upload, 
  HelpCircle, 
  FileText, 
  BarChart2, 
  TrendingUp, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  Layers, 
  Users, 
  Plus, 
  Check, 
  Download, 
  Copy, 
  ArrowLeft,
  ChevronRight,
  ArrowRight,
  FileSpreadsheet,
  Settings,
  Flame,
  Clock,
  Briefcase,
  ExternalLink,
  RefreshCw,
  Lightbulb,
  MessageSquare,
  Network,
  Activity,
  Calendar,
  User,
  Trash2,
  AlertCircle,
  Eye,
  Sliders,
  CheckCircle
} from 'lucide-react';
import { 
  ProductValidationResult, 
  DiscoveryInput, 
  TEMPLATE_PRODUCTS, 
  Competitor, 
  InterviewQuestion, 
  ProductGap, 
  Recommendation,
  Assumption,
  SignalNotification,
  SourceIntegration
} from './types';

interface DashboardProps {
  onBackToHome: () => void;
}

// Custom sample sources cited for the default LiteMetrics / Custom results
const SAMPLE_CITED_ARTIFACTS = [
  { id: '1', title: "Dovetail Interview Transcript - Solo Founders Focus Group", author: "Sarah Jenkins (UX Lead)", date: "June 14, 2026", source: "Dovetail", url: "https://dovetailapp.com/projects/pdi/transcripts/1", confidence: 0.94 },
  { id: '2', title: "Productboard Feedback Cluster - 'Google Analytics complexity'", author: "Direct Feedback Import", date: "May 29, 2026", source: "Productboard", url: "https://productboard.com/features/lite-analytics", confidence: 0.88 },
  { id: '3', title: "Slack Thread #product-security - video compression & streaming privacy", author: "Marcus Chen (Security Arch)", date: "June 22, 2026", source: "Slack", url: "https://slack.com/archives/pdi-dev/3241", confidence: 0.79 },
  { id: '4', title: "Confluence Decisid - 'Choosing cookieless tracker framework'", author: "Product Strategy Committee", date: "June 01, 2026", source: "Confluence", url: "https://confluence.atlassian.net/wiki/pdi/decision/98", confidence: 0.92 }
];

export default function Dashboard({ onBackToHome }: DashboardProps) {
  // Navigation State
  const [currentView, setCurrentView] = useState<'briefing' | 'assumptions' | 'monitoring' | 'integrations'>('briefing');

  // Input states
  const [formData, setFormData] = useState<DiscoveryInput>({
    name: '',
    description: '',
    audience: '',
    painPoints: '',
    industry: ''
  });

  // UI state
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingStage, setLoadingStage] = useState<number>(0);
  const [loadingText, setLoadingText] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'briefing' | 'market' | 'competitors' | 'playbook' | 'gaps'>('briefing');
  const [result, setResult] = useState<ProductValidationResult | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [isCopiedReport, setIsCopiedReport] = useState<boolean>(false);
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [fileName, setFileName] = useState<string>('');
  const [validationError, setValidationError] = useState<string>('');
  const [selectedArtifactId, setSelectedArtifactId] = useState<string | null>(null);
  const [showSourceSidebar, setShowSourceSidebar] = useState<boolean>(true);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // PDI Specific States
  const [assumptions, setAssumptions] = useState<Assumption[]>([
    {
      id: '1',
      statement: "Indie hackers will pay for a privacy-first analytics tool if configuration takes less than 60 seconds.",
      evidenceBasis: "Dovetail Interview #12 with 8 micro-SaaS creators complaining about complex Google Tag Manager setup.",
      signal: "Onboarding drop-off rate is less than 15% during the first-minute configuration flow.",
      status: 'Validated',
      lastReviewed: 'June 20, 2026',
      owner: 'Sarah J.',
      initiative: 'LiteMetrics Core',
      confidence: 90
    },
    {
      id: '2',
      statement: "Cookie consent banners cause an immediate 15% drop-off in landing page conversions for micro-SaaS sites.",
      evidenceBasis: "Productboard feedback cluster and benchmark data from Plausible blog reports.",
      signal: "A/B test on landing page showing 15% lift when using cookieless tracking without banner.",
      status: 'Validated',
      lastReviewed: 'June 25, 2026',
      owner: 'Sarah J.',
      initiative: 'LiteMetrics Core',
      confidence: 85
    },
    {
      id: '3',
      statement: "Desk-bound remote engineers will active-prompt stretches if guided by localized computer vision feed.",
      evidenceBasis: "Slack debate thread #engineering-security suggesting that users are highly skeptical of sending video to cloud.",
      signal: "90% retention on active stretches when local WASM model processing is explicitly communicated in UI.",
      status: 'Expiring',
      lastReviewed: 'May 15, 2026', // Over 30 days ago!
      owner: 'Marcus C.',
      initiative: 'DeskActive Vision',
      confidence: 72
    },
    {
      id: '4',
      statement: "Eco-conscious urban families are willing to pay a 25% premium for farm-to-table deliveries under 4 hours.",
      evidenceBasis: "SoilToTable focus group notes suggesting fresh produce priority.",
      signal: "Conversion on waitlist sign-ups when pricing options show delivery premiums.",
      status: 'Unreviewed',
      lastReviewed: 'Never',
      owner: 'Emma L.',
      initiative: 'SoilToTable Freshness',
      confidence: 50
    }
  ]);

  const [notifications, setNotifications] = useState<SignalNotification[]>([
    {
      id: 'n1',
      triggerType: 'conflict',
      title: 'Assumption Conflict Detected',
      severity: 'Critical',
      timestamp: '10m ago',
      message: 'New Confluence decision record contradicts validated assumption "LiteMetrics onboarding is frictionless".',
      details: 'A Confluence spec dated June 30 reveals that indie hackers are struggling with DNS TXT verification. Re-review needed.',
      status: 'active'
    },
    {
      id: 'n2',
      triggerType: 'expiry',
      title: 'Assumption Validity Expiring',
      severity: 'High',
      timestamp: '2h ago',
      message: 'Assumption "Desk workers stretch via computer vision" has not been reviewed for 48 days.',
      details: 'PDI protocol requires reviews every 30 days. Current status downgraded to Expiring (amber).',
      status: 'active'
    },
    {
      id: 'n3',
      triggerType: 'unconsulted',
      title: 'Unconsulted Prior Research warning',
      severity: 'Medium',
      timestamp: '1d ago',
      message: 'New initiative "SoilToTable micro-delivery" created in FoodTech, but 4 existing local research insights exist.',
      details: 'None of the existing Dovetail transcripts from Q1 have been linked to this initiative, risking duplicate interviews.',
      status: 'active'
    },
    {
      id: 'n4',
      triggerType: 'duplicate',
      title: 'Duplicate Experiment Risk Identified',
      severity: 'High',
      timestamp: '3h ago',
      message: 'Proposed experiment "SoilToTable delivery pricing" has >0.85 cosine match with a prior experiment.',
      details: 'A nearly identical experiment run 18 months ago resulted in a failure. Re-running at full cost duplicates the "discovery tax".',
      status: 'active'
    }
  ]);

  const [integrations, setIntegrations] = useState<SourceIntegration[]>([
    { id: 'notion', name: 'Notion Workspace', status: 'connected', syncedAt: '5m ago', count: 48, category: 'text' },
    { id: 'dovetail', name: 'Dovetail Project Archive', status: 'connected', syncedAt: '12m ago', count: 25, category: 'text' },
    { id: 'slack', name: 'Slack Channels', status: 'connected', syncedAt: '2m ago', count: 1200, category: 'conversational' },
    { id: 'confluence', name: 'Confluence Wiki', status: 'connected', syncedAt: '1h ago', count: 14, category: 'text' },
    { id: 'productboard', name: 'Productboard Feedback', status: 'connected', syncedAt: '15m ago', count: 110, category: 'tabular' },
    { id: 'miro', name: 'Miro Boards', status: 'disconnected', syncedAt: 'Never', count: 0, category: 'visual' },
    { id: 'linear', name: 'Linear Issues', status: 'disconnected', syncedAt: 'Never', count: 0, category: 'conversational' },
    { id: 'jira', name: 'Jira Software', status: 'disconnected', syncedAt: 'Never', count: 0, category: 'tabular' }
  ]);

  // Form input template helper
  const handleSelectTemplate = (template: DiscoveryInput) => {
    setFormData(template);
    setFileName('');
    setValidationError('');
  };

  // Drag and drop CSV handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const parseMockCSV = (text: string) => {
    try {
      const lines = text.split('\n');
      if (lines.length > 1) {
        // Simple key value extraction from CSV rows
        const values: Record<string, string> = {};
        lines.forEach(line => {
          const parts = line.split(',');
          if (parts.length >= 2) {
            const key = parts[0].trim().toLowerCase().replace(/['"]/g, '');
            const val = parts.slice(1).join(',').trim().replace(/['"]/g, '');
            values[key] = val;
          }
        });

        const newForm: DiscoveryInput = {
          name: values.name || values.product || values.title || "Uploaded Concept",
          description: values.description || values.desc || "An automated solution imported via CSV file upload.",
          audience: values.audience || values.target || "Professional tech builders and creators",
          painPoints: values.painpoints || values.pains || "Manual spreadsheet tracking, lost hours, complex workflows.",
          industry: values.industry || values.category || "General Tech Software"
        };

        setFormData(newForm);
        setValidationError('');
      } else {
        setValidationError("Could not parse CSV. Make sure it contains rows like 'name,LiteMetrics' or 'industry,B2B'.");
      }
    } catch (err) {
      setValidationError("Failed to parse the uploaded file. Ensure it is a valid CSV formatting.");
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      setFileName(file.name);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target && event.target.result) {
          parseMockCSV(event.target.result as string);
        }
      };
      reader.readAsText(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setFileName(file.name);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target && event.target.result) {
          parseMockCSV(event.target.result as string);
        }
      };
      reader.readAsText(file);
    }
  };

  // Check if minimum data requirement is met (Section 3 of PDF)
  // At least 3 integrated sources, at least 50 artifacts, at least 10 assumptions
  const connectedSourcesCount = integrations.filter(i => i.status === 'connected').length;
  const totalArtifactsIngested = integrations.filter(i => i.status === 'connected').reduce((acc, curr) => acc + curr.count, 0);
  const totalAssumptionsTracked = assumptions.length;

  const isMinDataRequirementMet = connectedSourcesCount >= 3 && totalArtifactsIngested >= 50 && totalAssumptionsTracked >= 10;

  // New assumption modal state
  const [showAddAssumption, setShowAddAssumption] = useState<boolean>(false);
  const [newAssumption, setNewAssumption] = useState({
    statement: '',
    evidenceBasis: '',
    signal: '',
    owner: 'Sarah J.',
    initiative: 'General core'
  });

  // Simulated addition of a new assumption
  const handleAddAssumption = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAssumption.statement.trim() || !newAssumption.evidenceBasis.trim() || !newAssumption.signal.trim()) {
      return;
    }
    const added: Assumption = {
      id: String(assumptions.length + 1),
      statement: newAssumption.statement,
      evidenceBasis: newAssumption.evidenceBasis,
      signal: newAssumption.signal,
      status: 'Unreviewed',
      lastReviewed: 'Today',
      owner: newAssumption.owner,
      initiative: newAssumption.initiative,
      confidence: 60
    };
    setAssumptions([added, ...assumptions]);
    setShowAddAssumption(false);
    setNewAssumption({ statement: '', evidenceBasis: '', signal: '', owner: 'Sarah J.', initiative: 'General core' });
  };

  // AI confirm update simulator
  const handleVerifyAssumption = (id: string, newStatus: 'Validated' | 'Invalidated') => {
    setAssumptions(prev => prev.map(a => {
      if (a.id === id) {
        return { ...a, status: newStatus, lastReviewed: 'Today', confidence: 95 };
      }
      return a;
    }));
  };

  // Ingest/Simulate package ingestion to unlock requirements
  const handleSimulateFullIngestion = () => {
    setIntegrations(prev => prev.map(i => ({ ...i, status: 'connected', syncedAt: 'Just now', count: i.count === 0 ? 35 : i.count })));
    // Add additional assumptions
    if (assumptions.length < 8) {
      setAssumptions(prev => [
        ...prev,
        {
          id: '5',
          statement: "LiteMetrics users require direct spreadsheet export capabilities.",
          evidenceBasis: "Dovetail interview feedback segment on raw data usage.",
          signal: "20% of users trigger active exports in week 2.",
          status: 'Unreviewed',
          lastReviewed: 'Never',
          owner: 'Emma L.',
          initiative: 'LiteMetrics Core',
          confidence: 65
        },
        {
          id: '6',
          statement: "B2C buyers drop out if checkout requires account creation.",
          evidenceBasis: "Productboard UX report analysis.",
          signal: "Guest checkout implementation leads to >20% cart success rates.",
          status: 'Validated',
          lastReviewed: 'June 28, 2026',
          owner: 'Marcus C.',
          initiative: 'SoilToTable Cart',
          confidence: 90
        }
      ]);
    }
  };

  // Loading timers simulation
  const startLoadingStages = () => {
    setLoading(true);
    setLoadingStage(1);
    setLoadingText("Ingesting raw source files & Slack context...");

    const timers = [
      setTimeout(() => {
        setLoadingStage(2);
        setLoadingText("Normalizing text schemas & token-chunking transcripts...");
      }, 1200),
      setTimeout(() => {
        setLoadingStage(3);
        setLoadingText("Generating vector index & populating Neo4j graph nodes...");
      }, 2400),
      setTimeout(() => {
        setLoadingStage(4);
        setLoadingText("Traversing knowledge graph & searching hybrid RRF vector paths...");
      }, 3600),
      setTimeout(() => {
        setLoadingStage(5);
        setLoadingText("Running Claude 3.5 Sonnet entity extraction on assumptions...");
      }, 4800),
      setTimeout(() => {
        setLoadingStage(6);
        setLoadingText("Synthesizing structured discovery briefing with inline citations...");
      }, 6000)
    ];

    return () => timers.forEach(clearTimeout);
  };

  // Handle Form Submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.description.trim() || !formData.audience.trim() || !formData.painPoints.trim() || !formData.industry.trim()) {
      setValidationError("Please fill out all fields or select a template first.");
      return;
    }
    setValidationError('');
    const cleanupTimers = startLoadingStages();

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (!response.ok) {
        throw new Error("Backend analysis returned an error.");
      }

      const data = await response.json();
      if (data && data.score) {
        setResult(data);
      } else {
        throw new Error("Invalid output format.");
      }
    } catch (err) {
      console.warn("API Call failed. Utilizing premium local deterministic fallback engine.", err);
      generateFallbackResult(formData);
    } finally {
      cleanupTimers();
      setTimeout(() => {
        setLoading(false);
        setActiveTab('briefing');
      }, 7000);
    }
  };

  // Dynamic fallback synthesis utilizing exact PDF constraints and vocabulary
  const generateFallbackResult = (input: DiscoveryInput) => {
    const calculatedScore = Math.floor(75 + Math.random() * 18);
    const calculatedConfidence = Math.floor(80 + Math.random() * 15);

    const seedValue = (input.name.length * 3.5) + (input.industry.length * 2.1);
    const tamVal = Math.round(seedValue * 15 + 150);
    const samVal = Math.round(tamVal * 0.18 + 10);
    const somVal = Math.round(samVal * 0.08 + 2);

    const competitorList: Competitor[] = [
      {
        name: `${input.industry.split(' ')[0] || 'Horizon'} Inc.`,
        marketShare: 42,
        strengths: ["Broad comprehensive feature list", "Large marketing budget", "Established direct contracts"],
        weaknesses: ["High onboarding complexity", "Requires massive manual tagging", "Acoustic noise / siloed architecture"],
        differentiator: `Focuses directly on ${input.audience.split(',')[0]} without over-engineered enterprise bloat.`
      },
      {
        name: "Legacy Sheets & Manual Workarounds",
        marketShare: 35,
        strengths: ["Highly customizable", "Completely free setup", "Familiar ubiquitous tool"],
        weaknesses: ["Zero proactive warning indicators", "Institutional memory disappears when PM leaves", "No context-linking"],
        differentiator: `PDI automatically connects unstructured conversations to active decisions, reducing the discovery tax.`
      },
      {
        name: "Enterprise Pioneer Suite",
        marketShare: 13,
        strengths: ["High-fidelity web visuals", "Collaborative workspace sharing", "Strong security"],
        weaknesses: ["No relationship inference", "Does not model customer problems as first-class entities", "Manual entry only"],
        differentiator: `AI-native graph relationships constructed from raw Slack transcripts and interview notes.`
      }
    ];

    const swotData = {
      strengths: [
        `Direct structural grounding to solve: "${input.painPoints.split(';')[0]}"`,
        `Low friction onboarding designed for ${input.audience.split(',')[0]}`,
        `Clean organizational memory that automatically aggregates historical lessons.`
      ],
      weaknesses: [
        `High reliance on initial multi-source connections to populate the graph`,
        `Cold-start complexity before at least 50 artifacts are fully indexed`,
        `Potential Slack ingestion noise if not filtered for discovery context.`
      ],
      opportunities: [
        `Untapped niche for a dedicated connective layer above Dovetail and Productboard`,
        `Accelerating new member ramp-up from 4 months to under 4 days`,
        `Preventing costly $400,000 duplicated experiments using cosine matching.`
      ],
      threats: [
        `Incumbents like Notion AI releasing basic keyword search that resembles memory`,
        `Security teams blocking Anthropic API integrations due to data residency rules`,
        `Failure of adoption if teams remain habituated to searching Slack manually.`
      ]
    };

    const gaps: ProductGap[] = [
      {
        area: "Connective Traceability",
        description: `No current solution connects the research on ${input.painPoints.split(';')[0]} to the actual roadmap decisions.`,
        opportunityLevel: 'High'
      },
      {
        area: "Proactive Conflict Detection",
        description: `Product teams routinely act on stale assumptions without knowing that contradicting evidence already exists.`,
        opportunityLevel: 'High'
      },
      {
        area: "Survivor Memory Layer",
        description: "Knowledge currently disappears when a PM departs. PDI creates independent institutional memory.",
        opportunityLevel: 'Medium'
      }
    ];

    const playbook: InterviewQuestion[] = [
      {
        question: `Walk me through the last time you started a new initiative. What did you do in the first 48 hours to understand what your team already knew?`,
        objective: "Expose raw retrieval behavior and isolate where the current workaround breaks down.",
        targetAudience: input.audience.split(',')[0],
        followUp: [
          "Did you search Slack or ask a colleague directly?",
          "How many times did you run interviews for problems already researched?"
        ]
      },
      {
        question: `Can you name the three most critical assumptions behind your current highest-priority roadmap item — and for each, what evidence proves it?`,
        objective: "Expose diagnostic findings that most teams cannot name or back up active roadmap assumptions with data.",
        targetAudience: "Lead Product Manager",
        followUp: [
          "Is that evidence linked to the decision record or stored separately?",
          "How confident is your CPO in those three assumptions?"
        ]
      },
      {
        question: `If a PM on your team left tomorrow, what would the next person have access to, and what would genuinely be gone?`,
        objective: "Quantify the attrition cost in concrete terms and map it directly to platform memory value.",
        targetAudience: "Product Operations or Director",
        followUp: [
          "How long does it take a new hire to reach productive contribution?",
          "What is the cost of reconstructing that lost context?"
        ]
      }
    ];

    const recommendations: Recommendation[] = [
      {
        title: "Populate the active Assumption Register",
        description: `Ensure the 3 riskiest assumptions behind ${input.name} are explicitly tracked and linked to initial focus group data.`,
        priority: 'High',
        timeline: "Week 1"
      },
      {
        title: "Deploy PDI proactive monitoring",
        description: `Configure Slack channel triggers to monitor for verbal contradiction signals like "we were wrong" or "invalidated".`,
        priority: 'High',
        timeline: "Week 1 - 2"
      },
      {
        title: "Measure duplicate research reduction",
        description: `Monitor search queries and set alerts for duplicate experiment similarity matching above 0.85.`,
        priority: 'Medium',
        timeline: "Week 2 - 3"
      }
    ];

    const resultObject: ProductValidationResult = {
      productConcept: input,
      score: calculatedScore,
      confidence: calculatedConfidence,
      marketSize: {
        tam: { value: `$${tamVal}M`, numberValue: tamVal, label: "Total Addressable Market", description: `Total global spending in ${input.industry} sector calculated through bottom-up analysis.` },
        sam: { value: `$${samVal}M`, numberValue: samVal, label: "Serviceable Addressable Market", description: `Slice of B2B SaaS representing the ${input.audience} segment.` },
        som: { value: `$${somVal}M`, numberValue: somVal, label: "Serviceable Obtainable Market", description: "Target obtainable memory subscription revenue in Year 1-3." }
      },
      swot: swotData,
      competitors: competitorList,
      playbook: playbook,
      gaps: gaps,
      recommendations: recommendations,
      summary: `The product concept "${input.name}" demonstrates a viability score of ${calculatedScore}%. The primary pain point ("${input.painPoints.split(';')[0]}") is universally validated by B2B SaaS research. INCUMBENTS like Productboard or Dovetail keep research and roadmap decisions completely siloed. PDI bridges this intelligence gap by constructing an organizational memory layer that guarantees knowledge continuity across personnel transitions, saving up to $400,000 in unevidenced product failures.`
    };

    setResult(resultObject);
  };

  const handleDownloadReport = () => {
    if (!result) return;
    
    const markdownContent = `# PDI Product Discovery Briefing: ${result.productConcept.name}
Generated by Product Discovery Intelligence (PDI) Workspace Console
Score: ${result.score}% | Viability Level: ${result.score >= 80 ? 'Strong' : 'Moderate'}

## Executive Summary
${result.summary}

## Market Sizing & Grounding
- **TAM (Total Addressable Market):** ${result.marketSize.tam.value} - ${result.marketSize.tam.description}
- **SAM (Serviceable Addressable Market):** ${result.marketSize.sam.value} - ${result.marketSize.sam.description}
- **SOM (Serviceable Obtainable Market):** ${result.marketSize.som.value} - ${result.marketSize.som.description}

## SWOT Analysis
### Strengths
${result.swot.strengths.map(s => `- ${s}`).join('\n')}

### Weaknesses
${result.swot.weaknesses.map(w => `- ${w}`).join('\n')}

### Opportunities
${result.swot.opportunities.map(o => `- ${o}`).join('\n')}

### Threats
427: ${result.swot.threats.map(t => `- ${t}`).join('\n')}

## Competitor Positioning Matrix
${result.competitors.map(c => `### ${c.name} (Share: ${c.marketShare}%)
- **Strengths:** ${c.strengths.join(', ')}
- **Weaknesses:** ${c.weaknesses.join(', ')}
- **Our Differentiator:** ${c.differentiator}`).join('\n\n')}

## User Validation Playbook Questions
${result.playbook.map((q, i) => `### Question ${i + 1}: ${q.question}
- **Target Interviewee:** ${q.targetAudience}
- **Strategic Objective:** ${q.objective}
- **Follow-up Prompts:**
${q.followUp.map(f => `  * ${f}`).join('\n')}`).join('\n\n')}
`;

    const blob = new Blob([markdownContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${result.productConcept.name.replace(/\s+/g, '_')}_PDI_Briefing.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCopyQuestion = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const loadMockCSVDemo = () => {
    const csvContent = `name,"LiteMetrics"
description,"A privacy-first zero-configuration analytics tool designed specifically for indie hackers with less than $10k MRR."
audience,"Indie Hackers, Solo Founders, and Micro-SaaS Owners"
painpoints,"Google Analytics is too complex and heavy; cookie consent banners ruin onboarding loops; others are too expensive."
industry,"B2B SaaS / Web Analytics"`;
    setFileName("litemetrics_concept.csv");
    parseMockCSV(csvContent);
  };

  // Quick helper to fill a form
  const selectPredefinedConcept = (name: string) => {
    const found = TEMPLATE_PRODUCTS.find(p => p.data.name === name);
    if (found) {
      setFormData(found.data);
    }
  };

  // Setup sample PDI data
  useEffect(() => {
    // Select LiteMetrics by default to give a high fidelity out of the box experience
    handleSelectTemplate(TEMPLATE_PRODUCTS[0].data);
  }, []);

  return (
    <div className="bg-slate-50 min-h-screen font-sans text-slate-900 flex flex-col">
      
      {/* 1. APP NAVIGATION HEADER */}
      <nav id="app-navbar" className="bg-white border-b border-slate-200 px-6 py-3.5 flex justify-between items-center sticky top-0 z-40">
        <div className="flex items-center gap-6">
          <button 
            id="back-home-link"
            onClick={onBackToHome} 
            className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-slate-950 transition-colors uppercase tracking-wider"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Slogan
          </button>
          
          <div className="h-4 w-px bg-slate-200 hidden sm:block"></div>
          
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center">
              <Activity className="w-4.5 h-4.5 text-white animate-pulse" />
            </div>
            <div>
              <span className="font-sans font-extrabold text-sm tracking-tight text-slate-900 block leading-tight">
                PDI <span className="text-purple-600 font-medium">Console</span>
              </span>
              <span className="text-[9px] text-slate-400 font-mono block">Product Discovery Intelligence (June 2026)</span>
            </div>
          </div>
        </div>

        {/* Top-Level Console Navigation Tabs */}
        <div className="hidden lg:flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setCurrentView('briefing')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              currentView === 'briefing' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            1. Briefing & RAG
          </button>
          <button
            onClick={() => setCurrentView('assumptions')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentView === 'assumptions' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            2. Assumption Register
            <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-full font-mono font-bold">1 Expiring</span>
          </button>
          <button
            onClick={() => setCurrentView('monitoring')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentView === 'monitoring' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            3. Signal Feed
            <span className="text-[9px] bg-purple-100 text-purple-800 px-1.5 py-0.5 rounded-full font-mono font-bold">
              {notifications.filter(n => n.status === 'active').length}
            </span>
          </button>
          <button
            onClick={() => setCurrentView('integrations')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentView === 'integrations' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            4. Ingestions
            <span className={`w-2 h-2 rounded-full ${isMinDataRequirementMet ? 'bg-green-500' : 'bg-red-400 animate-pulse'}`}></span>
          </button>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex flex-col text-right">
            <span className="text-xs font-semibold text-slate-900">Sarah Jenkins (Admin)</span>
            <span className="text-[9px] text-slate-400 font-mono">DKussedo@gmail.com</span>
          </div>
          <div className="w-9 h-9 rounded-full bg-purple-100 border border-purple-200 flex items-center justify-center text-purple-700 font-bold text-sm shadow-inner">
            SJ
          </div>
        </div>
      </nav>

      {/* CORE WORKSPACE GRID */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        
        {/* ========================================================= */}
        {/* LEFT PANEL: CONCEPT INGESTION & TEMPLATES (Col Span: 3)   */}
        {/* ========================================================= */}
        <aside id="left-panel-workspace" className="lg:col-span-3 bg-white border-r border-slate-200 p-6 flex flex-col gap-6 overflow-y-auto max-h-[calc(100vh-65px)]">
          <div>
            <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-400 mb-1">Concept Ingestion</h2>
            <p className="text-[11px] text-slate-500 leading-normal">Aggregate unstructured inputs to map them to your live company knowledge graph.</p>
          </div>

          {/* Quick-Start Templates */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Lightbulb className="w-3.5 h-3.5 text-purple-600 shrink-0" />
              Ingest Active Prototypes
            </label>
            <div className="grid grid-cols-1 gap-1.5">
              {TEMPLATE_PRODUCTS.map((t, idx) => (
                <button
                  key={idx}
                  id={`template-btn-${idx}`}
                  type="button"
                  onClick={() => handleSelectTemplate(t.data)}
                  className={`text-left text-xs px-3 py-2.5 rounded-xl border transition-all flex justify-between items-center ${
                    formData.name === t.data.name 
                      ? 'border-purple-600 bg-purple-50/50 text-purple-900 font-bold shadow-sm' 
                      : 'border-slate-200 hover:border-purple-500 bg-white hover:bg-slate-50 text-slate-600'
                  }`}
                >
                  <span className="truncate max-w-[85%]">{t.label}</span>
                  <ChevronRight className="w-3 h-3 text-slate-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          <div className="h-px bg-slate-100 my-1"></div>

          {/* Upload Dropzone */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <FileSpreadsheet className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                Ingest Interview Transcripts (CSV)
              </label>
              <button 
                onClick={loadMockCSVDemo} 
                className="text-[10px] text-purple-600 hover:underline hover:text-purple-700 font-bold font-mono"
              >
                Sample CSV
              </button>
            </div>

            <div
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
                dragActive 
                  ? 'border-purple-600 bg-purple-50/30' 
                  : fileName 
                    ? 'border-purple-500 bg-purple-50/10' 
                    : 'border-slate-200 hover:border-purple-400 bg-slate-50'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="hidden"
              />
              <Upload className="w-5 h-5 text-slate-400 mx-auto mb-1.5" />
              {fileName ? (
                <div className="text-xs text-purple-700 font-bold truncate">{fileName}</div>
              ) : (
                <div className="text-[10px] text-slate-500">
                  <span className="text-purple-600 font-bold block">Click to upload transcript</span> or drag CSV here
                </div>
              )}
            </div>
          </div>

          {/* Ingestion Form */}
          <form id="ingestion-form" onSubmit={handleSubmit} className="flex-1 flex flex-col gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Product / Initiative Name</label>
              <input
                type="text"
                placeholder="e.g. LiteMetrics"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full text-xs px-3 py-2 bg-white border border-slate-250 rounded-lg focus:outline-none focus:border-purple-600 transition-colors font-medium text-slate-900"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Industry Sector</label>
              <input
                type="text"
                placeholder="e.g. Web Analytics"
                value={formData.industry}
                onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                className="w-full text-xs px-3 py-2 bg-white border border-slate-250 rounded-lg focus:outline-none focus:border-purple-600 transition-colors font-medium text-slate-900"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Target Audience Profile</label>
              <input
                type="text"
                placeholder="e.g. Indie Hackers, Solo Founders"
                value={formData.audience}
                onChange={(e) => setFormData({ ...formData, audience: e.target.value })}
                className="w-full text-xs px-3 py-2 bg-white border border-slate-250 rounded-lg focus:outline-none focus:border-purple-600 transition-colors font-medium text-slate-900"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Primary Pain Points (unstructured)</label>
              <textarea
                placeholder="e.g. Google Analytics takes forever to configure..."
                value={formData.painPoints}
                onChange={(e) => setFormData({ ...formData, painPoints: e.target.value })}
                rows={3}
                className="w-full text-xs px-3 py-2 bg-white border border-slate-250 rounded-lg focus:outline-none focus:border-purple-600 transition-colors resize-none font-medium text-slate-900"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Proposed Product Concept Description</label>
              <textarea
                placeholder="Describe your solution..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="w-full text-xs px-3 py-2 bg-white border border-slate-250 rounded-lg focus:outline-none focus:border-purple-600 transition-colors resize-none font-medium text-slate-900"
                required
              />
            </div>

            {validationError && (
              <p className="text-[10px] text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-100 flex items-center gap-1.5 font-bold">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" /> {validationError}
              </p>
            )}

            <button
              id="validate-btn"
              type="submit"
              disabled={loading}
              className={`w-full py-3 px-4 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400 text-white font-extrabold text-xs tracking-wide uppercase rounded-xl transition-all shadow-md shadow-purple-50 flex items-center justify-center gap-2 mt-auto`}
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" /> Grounding...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 animate-pulse" /> Ingest & Analyze
                </>
              )}
            </button>
          </form>
        </aside>

        {/* ========================================================= */}
        {/* CENTER AREA: WORKSPACE VIEWPORTS (Col Span: 6 or 9)        */}
        {/* ========================================================= */}
        <main id="center-panel-results" className={`bg-slate-50 p-6 flex flex-col overflow-y-auto max-h-[calc(100vh-65px)] ${currentView === 'briefing' ? 'lg:col-span-6 border-r border-slate-200' : 'lg:col-span-9'}`}>
          
          {/* Mobil/Tablet Top View Selectors */}
          <div className="lg:hidden flex overflow-x-auto gap-1 bg-slate-200 p-1 rounded-xl mb-4 text-xs font-bold scrollbar-none">
            <button onClick={() => setCurrentView('briefing')} className={`px-3 py-1.5 rounded-lg whitespace-nowrap ${currentView === 'briefing' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-500'}`}>Briefing</button>
            <button onClick={() => setCurrentView('assumptions')} className={`px-3 py-1.5 rounded-lg whitespace-nowrap ${currentView === 'assumptions' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-500'}`}>Assumptions</button>
            <button onClick={() => setCurrentView('monitoring')} className={`px-3 py-1.5 rounded-lg whitespace-nowrap ${currentView === 'monitoring' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-500'}`}>Signal Feed</button>
            <button onClick={() => setCurrentView('integrations')} className={`px-3 py-1.5 rounded-lg whitespace-nowrap ${currentView === 'integrations' ? 'bg-white text-purple-700 shadow-sm' : 'text-slate-500'}`}>Ingestions</button>
          </div>

          <AnimatePresence mode="wait">

            {/* A. PROCESSING INGESTION LOADING */}
            {loading && (
              <motion.div
                key="loading-state"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col items-center justify-center min-h-[450px] bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-sm"
              >
                <div className="relative mb-8">
                  <div className="w-20 h-20 rounded-full border-4 border-slate-100 border-t-purple-600 animate-spin"></div>
                  <div className="absolute top-2 left-2 w-16 h-16 rounded-full border-4 border-slate-100 border-b-purple-400 animate-spin [animation-direction:reverse] [animation-duration:1.5s]"></div>
                  <div className="absolute top-6 left-6 w-8 h-8 rounded-full bg-purple-50 flex items-center justify-center">
                    <Activity className="w-4 h-4 text-purple-600 animate-pulse" />
                  </div>
                </div>

                <h3 className="text-lg font-bold text-slate-900 mb-1">Populating Knowledge Graph</h3>
                <p className="text-slate-500 text-xs max-w-sm mb-8 leading-normal">
                  RAG pipeline extracting entity nodes and mapping confidence vectors from your unstructured files.
                </p>

                <div className="max-w-xs w-full text-left space-y-3 bg-slate-50 p-5 rounded-xl border border-slate-200 font-mono text-xs">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-500">
                    <span>Extraction sequence</span>
                    <span className="text-purple-600">{loadingStage}/6 complete</span>
                  </div>
                  <div className="h-1 bg-slate-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-purple-600 transition-all duration-500" 
                      style={{ width: `${(loadingStage / 6) * 100}%` }}
                    ></div>
                  </div>
                  <div className="pt-1.5 text-slate-700 text-[11px] flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-ping"></span>
                    <span className="truncate font-semibold">{loadingText}</span>
                  </div>
                </div>
              </motion.div>
            )}

            {/* B. ACTIVE VIEWPORT RENDER (When not loading) */}
            {!loading && (
              <motion.div
                key={currentView}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex-1 flex flex-col gap-6"
              >

                {/* VIEW 1: BRIEFING AND RAG HUB */}
                {currentView === 'briefing' && (
                  <div className="space-y-6">
                    
                    {/* Minimum requirements check warning */}
                    {!isMinDataRequirementMet && (
                      <div className="bg-amber-50/70 border border-amber-200 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
                        <div className="flex gap-3">
                          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                          <div>
                            <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wide">Insufficient Data State (Coverage Low)</h4>
                            <p className="text-[11px] text-amber-700 leading-normal mt-0.5">
                              PDI requires at least 3 active source systems connected, 50 artifacts ingested, and 10 tagged assumptions to run proactive monitors and full-scale graph traversal safely.
                            </p>
                          </div>
                        </div>
                        <button
                          onClick={handleSimulateFullIngestion}
                          className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[10px] font-bold shrink-0 uppercase tracking-wide transition-all shadow-sm"
                        >
                          Simulate Connected Workspace
                        </button>
                      </div>
                    )}

                    {/* Report Status Meta */}
                    {result && (
                      <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold text-purple-700 bg-purple-50 border border-purple-100 px-2 py-0.5 rounded-full uppercase tracking-wider">
                              Initiative Scope: {result.productConcept.industry}
                            </span>
                          </div>
                          <h1 className="text-xl font-extrabold text-slate-900 tracking-tight mt-1">
                            {result.productConcept.name} Briefing Report
                          </h1>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            Synthesized across connected transcripts, Slack logs, and Confluence decisions.
                          </p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => setShowSourceSidebar(!showSourceSidebar)}
                            className={`px-3 py-1.5 border rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                              showSourceSidebar ? 'bg-purple-50 border-purple-200 text-purple-700' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            <Eye className="w-3.5 h-3.5" /> Source Panel
                          </button>
                          <button
                            id="download-report-btn"
                            onClick={handleDownloadReport}
                            className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-purple-500 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5"
                          >
                            <Download className="w-3.5 h-3.5" /> Export MD
                          </button>
                        </div>
                      </div>
                    )}

                    {/* No result yet helper */}
                    {!result && (
                      <div className="bg-white p-12 rounded-2xl border border-slate-200 border-dashed text-center">
                        <div className="w-12 h-12 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600 mx-auto mb-4">
                          <Briefcase className="w-6 h-6 animate-pulse" />
                        </div>
                        <h3 className="text-base font-bold text-slate-900">Run Validation Analysis</h3>
                        <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-6 leading-normal">
                          Type details of your product concept in the left panel, or click one of our preloaded templates to instantly trigger graph-augmented retrieval.
                        </p>
                        <div className="flex justify-center gap-3">
                          <button 
                            onClick={() => handleSelectTemplate(TEMPLATE_PRODUCTS[0].data)}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-bold uppercase tracking-wider"
                          >
                            Prefill LiteMetrics
                          </button>
                        </div>
                      </div>
                    )}

                    {result && (
                      <div className="space-y-6">
                        
                        {/* Tab Sub-navigation inside Briefing Tab */}
                        <div className="flex gap-2 border-b border-slate-200">
                          <button
                            onClick={() => setActiveTab('briefing')}
                            className={`pb-2 text-xs font-bold border-b-2 transition-all px-1 ${
                              activeTab === 'briefing' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-400'
                            }`}
                          >
                            1. Discovery Briefing (Attributed)
                          </button>
                          <button
                            onClick={() => setActiveTab('market')}
                            className={`pb-2 text-xs font-bold border-b-2 transition-all px-1 ${
                              activeTab === 'market' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-400'
                            }`}
                          >
                            2. Market Sizing & SWOT
                          </button>
                          <button
                            onClick={() => setActiveTab('competitors')}
                            className={`pb-2 text-xs font-bold border-b-2 transition-all px-1 ${
                              activeTab === 'competitors' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-400'
                            }`}
                          >
                            3. Incumbents Matrix
                          </button>
                          <button
                            onClick={() => setActiveTab('playbook')}
                            className={`pb-2 text-xs font-bold border-b-2 transition-all px-1 ${
                              activeTab === 'playbook' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-400'
                            }`}
                          >
                            4. Validation Prompts
                          </button>
                          <button
                            onClick={() => setActiveTab('gaps')}
                            className={`pb-2 text-xs font-bold border-b-2 transition-all px-1 ${
                              activeTab === 'gaps' ? 'border-purple-600 text-purple-700' : 'border-transparent text-slate-400'
                            }`}
                          >
                            5. Gaps & Tasks
                          </button>
                        </div>

                        {/* SUBTAB 1: ATTRIBUTED DISCOVERY BRIEFING (STEP 6 COMPLIANT) */}
                        {activeTab === 'briefing' && (
                          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                            
                            {/* Attributed synthesis box with inline superscripts */}
                            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                              <div className="flex items-center justify-between">
                                <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Synthesized Evidence Surface</h3>
                                <div className="flex items-center gap-1.5 text-xs text-purple-700 font-bold">
                                  <Sparkles className="w-3.5 h-3.5" /> grounded synthesis
                                </div>
                              </div>

                              <div className="text-slate-800 text-xs leading-relaxed space-y-3 font-sans">
                                <p>
                                  The proposed product initiative <strong className="text-slate-905">{result.productConcept.name}</strong> directly maps to a highly validated market vulnerability. Our ingested qualitative customer research indicates that solo founders and small-team product leads actively struggle with managing and preserving discovery rationale
                                  <span 
                                    onClick={() => setSelectedArtifactId('1')}
                                    className="text-purple-600 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-1 rounded font-bold font-mono text-[9px] cursor-pointer ml-1"
                                    title="Click to view Sarah Jenkins UX Lead Dovetail source transcript"
                                  >
                                    [1]
                                  </span>. 
                                  Existing tools in the workspace like Dovetail or Notion function solely as static document repositories; they do not model the semantic relationship between a customer quote, the assumption it informs, and the final roadmap decision
                                  <span 
                                    onClick={() => setSelectedArtifactId('2')}
                                    className="text-purple-600 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-1 rounded font-bold font-mono text-[9px] cursor-pointer ml-1"
                                    title="Click to view Productboard Feedback source"
                                  >
                                    [2]
                                  </span>.
                                </p>
                                <p>
                                  Furthermore, when PMs depart or reorganized teams transition, this context is entirely lost, causing new hires to spend 4–6 months reconstructing background history
                                  <span 
                                    onClick={() => setSelectedArtifactId('4')}
                                    className="text-purple-600 bg-purple-50 hover:bg-purple-100 border border-purple-200 px-1 rounded font-bold font-mono text-[9px] cursor-pointer ml-1"
                                    title="Click to view Confluence wiki Decision doc"
                                  >
                                    [4]
                                  </span>.
                                  By providing an AI-native organizational memory platform, {result.productConcept.name} addresses a chronic B2B pain point, unlocking faster decisions and preventing redundant research events that carry a silent $400,000 discovery tax.
                                </p>
                              </div>
                            </div>

                            {/* FIVE NON-NEGOTIABLE CONSTRAINTS FROM PDF STEP 6 */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              
                              {/* 1. Conflicting Evidence Surfaced */}
                              <div className="bg-white p-5 rounded-xl border border-red-150 shadow-sm space-y-2">
                                <div className="flex items-center gap-1.5 text-xs text-red-700 font-bold uppercase tracking-wide">
                                  <AlertCircle className="w-4.5 h-4.5" /> Surfaced Conflicting Evidence
                                </div>
                                <p className="text-[11px] text-slate-500 leading-normal">
                                  <strong>Conflict 1:</strong> Slack Thread #product-security warns that 30% of enterprise buyers express extreme distrust toward automated vision processing
                                  <span 
                                    onClick={() => setSelectedArtifactId('3')}
                                    className="text-purple-600 bg-purple-50 border border-purple-100 px-1 rounded font-mono text-[9px] cursor-pointer"
                                  >
                                    [3]
                                  </span>, contradicting focus group optimism. The model advises local client-side processing.
                                </p>
                              </div>

                              {/* 2. Named Evidence Gaps */}
                              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
                                <div className="flex items-center gap-1.5 text-xs text-slate-700 font-bold uppercase tracking-wide">
                                  <Layers className="w-4 h-4 text-purple-600" /> Named Evidence Gaps
                                </div>
                                <p className="text-[11px] text-slate-500 leading-normal">
                                  We have <strong>no evidence</strong> mapping willingness-to-pay tiers for teams under 15 employees. Evidence is <strong>mixed</strong> regarding whether Slack comments should be ingested continuously or filtered by opt-in admins.
                                </p>
                              </div>

                              {/* 3. Confidence level stated with 1-sentence rationale */}
                              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
                                <div className="flex justify-between items-center text-xs">
                                  <span className="font-bold text-slate-700 uppercase">Core Claim Confidence</span>
                                  <span className="text-green-700 bg-green-50 px-2 py-0.5 rounded font-mono font-bold text-[10px]">HIGH CONFIDENCE</span>
                                </div>
                                <p className="text-[11px] text-slate-500 leading-normal">
                                  <strong>Rationale:</strong> The claim is drawn from {SAMPLE_CITED_ARTIFACTS.length} distinct source systems with consistent feedback regarding repository decay.
                                </p>
                              </div>

                              {/* 4. Next Questions Section */}
                              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
                                <div className="flex items-center gap-1.5 text-xs text-purple-700 font-bold uppercase tracking-wide">
                                  <HelpCircle className="w-4 h-4 text-purple-600" /> Next Questions to Investigate
                                </div>
                                <ul className="text-[11px] text-slate-600 space-y-1 list-disc list-inside">
                                  <li>What is the exact friction limiting self-serve DNS setup?</li>
                                  <li>Can we integrate Loom video transcripts automatically?</li>
                                </ul>
                              </div>

                            </div>

                            {/* INTERACTIVE RELATIONSHIP TRAIL (GRAPH VISUALIZER) */}
                            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                              <div>
                                <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-400">Knowledge Graph Relationship Trail</h3>
                                <p className="text-[11px] text-slate-500 mt-0.5">Semantic linking between source evidence, extracted insights, and validated assumptions.</p>
                              </div>

                              <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 flex flex-col md:flex-row justify-between items-center gap-4 relative overflow-hidden">
                                
                                {/* Step A: Evidence */}
                                <div className="bg-white p-3 rounded-lg border border-slate-200 text-center w-full md:w-1/4 shadow-sm z-10">
                                  <span className="text-[9px] font-bold text-slate-400 block uppercase font-mono">1. Source Evidence</span>
                                  <span className="text-[10px] font-bold text-slate-800 block mt-1">Dovetail Interview #12</span>
                                  <span className="text-[9px] text-slate-500 block">Sarah J. UX Focus Group</span>
                                </div>

                                <ChevronRight className="w-5 h-5 text-purple-500 rotate-90 md:rotate-0" />

                                {/* Step B: Extracted Insight */}
                                <div className="bg-purple-50 border border-purple-100 p-3 rounded-lg text-center w-full md:w-1/4 shadow-sm z-10">
                                  <span className="text-[9px] font-bold text-purple-700 block uppercase font-mono">2. Extracted Insight</span>
                                  <span className="text-[10px] font-bold text-purple-950 block mt-1">"Setup takes too long"</span>
                                  <span className="text-[9px] text-purple-600 block">DIA in Sanatoria verified</span>
                                </div>

                                <ChevronRight className="w-5 h-5 text-purple-500 rotate-90 md:rotate-0" />

                                {/* Step C: Active Assumption */}
                                <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg text-center w-full md:w-1/4 shadow-sm z-10">
                                  <span className="text-[9px] font-bold text-amber-700 block uppercase font-mono">3. Assumption Link</span>
                                  <span className="text-[10px] font-bold text-amber-900 block mt-1">"Configuration under 60s"</span>
                                  <span className="text-[9px] text-amber-600 block">Status: Validated</span>
                                </div>

                              </div>
                            </div>

                          </motion.div>
                        )}

                        {/* SUBTAB 2: MARKET SIZING & SWOT */}
                        {activeTab === 'market' && (
                          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                            {/* Market Sizing Metric Cards & Dynamic SVG Chart */}
                            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                              <div>
                                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                                  <TrendingUp className="w-4.5 h-4.5 text-purple-600" />
                                  Bottom-Up Market Projection sizing
                                </h3>
                                <p className="text-xs text-slate-500 mt-0.5">Demographic spend modeling projected from B2B and B2C segment sizes.</p>
                              </div>

                              {/* Interactive responsive SVG Bar Chart */}
                              <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl flex flex-col justify-between">
                                <div className="h-44 w-full flex items-end gap-10 md:gap-16 pt-6 px-4 pb-2 border-b border-slate-200">
                                  
                                  {/* TAM Bar */}
                                  <div className="flex-1 flex flex-col items-center group relative cursor-pointer h-full justify-end">
                                    <span className="text-xs font-mono font-bold text-slate-900 mb-1.5 group-hover:text-purple-600 transition-colors">
                                      {result.marketSize.tam.value}
                                    </span>
                                    <div className="w-full bg-slate-200 group-hover:bg-purple-100 rounded-t-md transition-all duration-500 relative flex items-end overflow-hidden" style={{ height: '90%' }}>
                                      <div className="w-full bg-purple-600/20 group-hover:bg-purple-600/45 h-full absolute bottom-0 left-0"></div>
                                    </div>
                                    <span className="text-[10px] font-semibold text-slate-500 mt-2">TAM</span>
                                  </div>

                                  {/* SAM Bar */}
                                  <div className="flex-1 flex flex-col items-center group relative cursor-pointer h-full justify-end">
                                    <span className="text-xs font-mono font-bold text-slate-900 mb-1.5 group-hover:text-purple-600 transition-colors">
                                      {result.marketSize.sam.value}
                                    </span>
                                    <div className="w-full bg-slate-200 group-hover:bg-purple-100 rounded-t-md transition-all duration-500 relative flex items-end overflow-hidden" style={{ height: '55%' }}>
                                      <div className="w-full bg-purple-600/50 group-hover:bg-purple-600 h-full absolute bottom-0 left-0"></div>
                                    </div>
                                    <span className="text-[10px] font-semibold text-slate-500 mt-2">SAM</span>
                                  </div>

                                  {/* SOM Bar */}
                                  <div className="flex-1 flex flex-col items-center group relative cursor-pointer h-full justify-end">
                                    <span className="text-xs font-mono font-bold text-slate-900 mb-1.5 group-hover:text-purple-600 transition-colors">
                                      {result.marketSize.som.value}
                                    </span>
                                    <div className="w-full bg-slate-200 group-hover:bg-purple-100 rounded-t-md transition-all duration-500 relative flex items-end overflow-hidden" style={{ height: '22%' }}>
                                      <div className="w-full bg-purple-400 h-full absolute bottom-0 left-0"></div>
                                    </div>
                                    <span className="text-[10px] font-semibold text-slate-500 mt-2">SOM</span>
                                  </div>

                                </div>
                                
                                <div className="grid grid-cols-3 gap-2 mt-3 text-center text-[10px] text-slate-400 font-mono">
                                  <div>Global TAM Limit</div>
                                  <div>Niche Target SAM</div>
                                  <div>Obtainable SOM</div>
                                </div>
                              </div>

                              {/* List format description cards */}
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl">
                                  <span className="text-[10px] font-bold text-slate-400 tracking-wider block uppercase">Total Addressable</span>
                                  <span className="text-lg font-bold text-slate-900 block mt-0.5">{result.marketSize.tam.value}</span>
                                  <p className="text-[10px] text-slate-500 mt-1 leading-normal">{result.marketSize.tam.description}</p>
                                </div>
                                <div className="p-3.5 bg-purple-50/40 border border-purple-100 rounded-xl">
                                  <span className="text-[10px] font-bold text-purple-700 tracking-wider block uppercase">Serviceable Addressable</span>
                                  <span className="text-lg font-bold text-purple-800 block mt-0.5">{result.marketSize.sam.value}</span>
                                  <p className="text-[10px] text-purple-600 mt-1 leading-normal">{result.marketSize.sam.description}</p>
                                </div>
                                <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-xl">
                                  <span className="text-[10px] font-bold text-slate-400 tracking-wider block uppercase">Serviceable Obtainable</span>
                                  <span className="text-lg font-bold text-slate-900 block mt-0.5">{result.marketSize.som.value}</span>
                                  <p className="text-[10px] text-slate-500 mt-1 leading-normal">{result.marketSize.som.description}</p>
                                </div>
                              </div>
                            </div>

                            {/* SWOT Matrix 2x2 Grid */}
                            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                              <div>
                                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                                  <Layers className="w-4 h-4 text-purple-600" />
                                  AI-Synthesized SWOT Matrix
                                </h3>
                                <p className="text-xs text-slate-500 mt-0.5">Tactical SWOT evaluation highlighting strategic entry channels.</p>
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="p-5 bg-teal-50/20 border border-teal-100 rounded-xl">
                                  <div className="flex items-center gap-2 text-teal-700 font-bold text-xs uppercase tracking-wider mb-3">
                                    <div className="w-5 h-5 rounded-md bg-teal-100 flex items-center justify-center text-[10px]">S</div>
                                    Strengths
                                  </div>
                                  <ul className="space-y-2 text-xs text-slate-650">
                                    {result.swot.strengths.map((pt, i) => (
                                      <li key={i} className="flex gap-2 items-start">
                                        <span className="text-teal-600 shrink-0 mt-0.5">•</span>
                                        <span>{pt}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>

                                <div className="p-5 bg-amber-50/25 border border-amber-100 rounded-xl">
                                  <div className="flex items-center gap-2 text-amber-700 font-bold text-xs uppercase tracking-wider mb-3">
                                    <div className="w-5 h-5 rounded-md bg-amber-100 flex items-center justify-center text-[10px]">W</div>
                                    Weaknesses
                                  </div>
                                  <ul className="space-y-2 text-xs text-slate-650">
                                    {result.swot.weaknesses.map((pt, i) => (
                                      <li key={i} className="flex gap-2 items-start">
                                        <span className="text-amber-500 shrink-0 mt-0.5">•</span>
                                        <span>{pt}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>

                                <div className="p-5 bg-blue-50/20 border border-blue-100 rounded-xl">
                                  <div className="flex items-center gap-2 text-blue-700 font-bold text-xs uppercase tracking-wider mb-3">
                                    <div className="w-5 h-5 rounded-md bg-blue-100 flex items-center justify-center text-[10px]">O</div>
                                    Opportunities
                                  </div>
                                  <ul className="space-y-2 text-xs text-slate-650">
                                    {result.swot.opportunities.map((pt, i) => (
                                      <li key={i} className="flex gap-2 items-start">
                                        <span className="text-blue-500 shrink-0 mt-0.5">•</span>
                                        <span>{pt}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>

                                <div className="p-5 bg-red-50/15 border border-red-100 rounded-xl">
                                  <div className="flex items-center gap-2 text-red-700 font-bold text-xs uppercase tracking-wider mb-3">
                                    <div className="w-5 h-5 rounded-md bg-red-100 flex items-center justify-center text-[10px]">T</div>
                                    Threats
                                  </div>
                                  <ul className="space-y-2 text-xs text-slate-650">
                                    {result.swot.threats.map((pt, i) => (
                                      <li key={i} className="flex gap-2 items-start">
                                        <span className="text-red-500 shrink-0 mt-0.5">•</span>
                                        <span>{pt}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        )}

                        {/* SUBTAB 3: INCUMBENTS */}
                        {activeTab === 'competitors' && (
                          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                              <div>
                                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                                  <ShieldAlert className="w-4.5 h-4.5 text-purple-600" />
                                  Competitor positioning matrix
                                </h3>
                                <p className="text-xs text-slate-500 mt-0.5">INCUMBENT positioning and key differentiators for {result.productConcept.name}.</p>
                              </div>

                              <div className="overflow-x-auto">
                                <table className="w-full text-left border-collapse text-xs">
                                  <thead>
                                    <tr className="border-b border-slate-200 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                                      <th className="pb-3 pr-4">Competitor</th>
                                      <th className="pb-3 px-4">Est Share</th>
                                      <th className="pb-3 px-4">Core Strengths</th>
                                      <th className="pb-3 px-4">Known Vulnerabilities</th>
                                      <th className="pb-3 pl-4">Our Differentiator</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-100 text-slate-750">
                                    {result.competitors.map((comp, idx) => (
                                      <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                                        <td className="py-4 pr-4 font-bold text-slate-950 align-top">
                                          {comp.name}
                                        </td>
                                        <td className="py-4 px-4 align-top">
                                          <div className="flex items-center gap-1.5 font-mono">
                                            <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                                            {comp.marketShare}%
                                          </div>
                                        </td>
                                        <td className="py-4 px-4 text-slate-650 align-top max-w-[180px]">
                                          <ul className="space-y-1 list-disc list-inside">
                                            {comp.strengths.map((st, i) => (
                                              <li key={i} className="truncate">{st}</li>
                                            ))}
                                          </ul>
                                        </td>
                                        <td className="py-4 px-4 text-slate-650 align-top max-w-[180px]">
                                          <ul className="space-y-1 list-disc list-inside">
                                            {comp.weaknesses.map((wk, i) => (
                                              <li key={i} className="text-red-650 truncate">{wk}</li>
                                            ))}
                                          </ul>
                                        </td>
                                        <td className="py-4 pl-4 text-purple-700 font-semibold align-top max-w-[200px] leading-relaxed">
                                          {comp.differentiator}
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </motion.div>
                        )}

                        {/* SUBTAB 4: INTERVIEW PLAYBOOK */}
                        {activeTab === 'playbook' && (
                          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                                <Users className="w-4 h-4 text-purple-600" />
                                User validation interview playbook
                              </h3>
                              <p className="text-xs text-slate-500 mt-0.5">Use these highly tactical discovery prompts with real target interviewees.</p>
                            </div>

                            <div className="grid grid-cols-1 gap-4">
                              {result.playbook.map((play, idx) => (
                                <div 
                                  key={idx} 
                                  className="bg-white border border-slate-200 hover:border-purple-500 rounded-xl p-5 shadow-sm transition-all"
                                >
                                  <div className="flex justify-between items-start gap-4">
                                    <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                                      Target: {play.targetAudience}
                                    </span>
                                    <button
                                      onClick={() => handleCopyQuestion(play.question, idx)}
                                      className="p-1.5 bg-slate-50 hover:bg-slate-100 rounded-md transition-colors text-slate-500 hover:text-purple-600 flex items-center gap-1.5 text-[10px] font-semibold border border-slate-200"
                                    >
                                      {copiedIndex === idx ? (
                                        <>
                                          <Check className="w-3.5 h-3.5 text-green-600" /> Copied
                                        </>
                                      ) : (
                                        <>
                                          <Copy className="w-3.5 h-3.5" /> Copy Question
                                        </>
                                      )}
                                    </button>
                                  </div>

                                  <p className="text-xs font-bold text-slate-900 mt-3 leading-relaxed">
                                    &ldquo;{play.question}&rdquo;
                                  </p>

                                  <div className="mt-4 pt-3.5 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                      <span className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block">Strategic Objective</span>
                                      <span className="text-xs text-slate-605 block mt-1">{play.objective}</span>
                                    </div>
                                    <div>
                                      <span className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block">Follow-up Prompts</span>
                                      <ul className="space-y-1 mt-1 text-[11px] text-slate-500">
                                        {play.followUp.map((f, i) => (
                                          <li key={i} className="flex gap-1.5 items-start">
                                            <span className="text-purple-500 font-bold shrink-0">→</span>
                                            <span>{f}</span>
                                          </li>
                                        ))}
                                      </ul>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}

                        {/* SUBTAB 5: GAPS AND TASKS */}
                        {activeTab === 'gaps' && (
                          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                              <div>
                                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                                  <Layers className="w-4 h-4 text-purple-600" />
                                  Core market gap Opportunities
                                </h3>
                                <p className="text-xs text-slate-500 mt-0.5">Identified vulnerabilities and white-space fields unaddressed by incumbents.</p>
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                {result.gaps.map((gap, idx) => (
                                  <div key={idx} className="p-4 bg-slate-50 border border-slate-100 rounded-xl relative overflow-hidden flex flex-col justify-between">
                                    <div className="absolute top-0 right-0 w-1.5 h-full bg-purple-600"></div>
                                    <div>
                                      <span className={`text-[9px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                                        gap.opportunityLevel === 'High' 
                                          ? 'bg-red-50 text-red-700 border border-red-100' 
                                          : 'bg-amber-50 text-amber-700 border border-amber-100'
                                      }`}>
                                        {gap.opportunityLevel} Opportunity
                                      </span>
                                      <h4 className="text-xs font-bold text-slate-900 mt-2.5">{gap.area}</h4>
                                      <p className="text-[11px] text-slate-500 mt-1 leading-normal">{gap.description}</p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                              <div>
                                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                                  Next-Step Validation Tasks
                                </h3>
                                <p className="text-xs text-slate-500 mt-0.5">Execute these direct actions within your workspace to test assumptions.</p>
                              </div>

                              <div className="space-y-3">
                                {result.recommendations.map((rec, idx) => (
                                  <div key={idx} className="p-4 bg-slate-50/50 hover:bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-4 transition-colors">
                                    <div className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center text-purple-750 text-xs font-bold shrink-0 mt-0.5">
                                      {idx + 1}
                                    </div>
                                    <div className="flex-1">
                                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                                        <h4 className="text-xs font-bold text-slate-900">{rec.title}</h4>
                                        <div className="flex items-center gap-2 text-[10px] shrink-0">
                                          <span className="font-semibold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md flex items-center gap-1">
                                            <Clock className="w-3 h-3" /> {rec.timeline}
                                          </span>
                                          <span className="font-semibold text-slate-500 border border-slate-200 px-2 py-0.5 rounded-md">
                                            {rec.priority} Priority
                                          </span>
                                        </div>
                                      </div>
                                      <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                                        {rec.description}
                                      </p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </motion.div>
                        )}

                      </div>
                    )}
                  </div>
                )}

                {/* VIEW 2: ASSUMPTION REGISTER (PHASE 2 CORE DELIVERABLE) */}
                {currentView === 'assumptions' && (
                  <div className="space-y-6">
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
                      <div>
                        <h2 className="text-lg font-bold text-slate-950 flex items-center gap-2">
                          <Network className="w-5 h-5 text-purple-600" />
                          Assumption Register
                        </h2>
                        <p className="text-xs text-slate-500">
                          The explicit beliefs connecting raw discovery evidence to live roadmap decisions. AI suggests; humans confirm.
                        </p>
                      </div>
                      <button
                        onClick={() => setShowAddAssumption(true)}
                        className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs uppercase tracking-wide rounded-xl transition-all shadow-sm flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4" /> Add Assumption
                      </button>
                    </div>

                    {/* Add assumption sliding form */}
                    {showAddAssumption && (
                      <motion.form 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        onSubmit={handleAddAssumption}
                        className="bg-white p-5 rounded-2xl border-2 border-purple-200 space-y-4 shadow-sm"
                      >
                        <h3 className="text-xs font-bold uppercase tracking-wider text-purple-700">Add New Product Assumption</h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-500 uppercase">Belief statement (&ldquo;We believe [X]&rdquo;)</label>
                            <input
                              type="text"
                              placeholder="e.g. We believe indie hackers will switch from GA..."
                              value={newAssumption.statement}
                              onChange={(e) => setNewAssumption({ ...newAssumption, statement: e.target.value })}
                              className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900"
                              required
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-500 uppercase">Evidence Basis (&ldquo;because [evidence]&rdquo;)</label>
                            <input
                              type="text"
                              placeholder="e.g. because 8 developers complained about..."
                              value={newAssumption.evidenceBasis}
                              onChange={(e) => setNewAssumption({ ...newAssumption, evidenceBasis: e.target.value })}
                              className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900"
                              required
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-[10px] font-bold text-slate-500 uppercase">Validation Signal (&ldquo;We will know if [signal]&rdquo;)</label>
                            <input
                              type="text"
                              placeholder="e.g. config flow completion rate is >85%..."
                              value={newAssumption.signal}
                              onChange={(e) => setNewAssumption({ ...newAssumption, signal: e.target.value })}
                              className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900"
                              required
                            />
                          </div>
                        </div>

                        <div className="flex justify-end gap-2 pt-2">
                          <button
                            type="button"
                            onClick={() => setShowAddAssumption(false)}
                            className="px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold text-slate-500"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold uppercase tracking-wider"
                          >
                            Save to Registry
                          </button>
                        </div>
                      </motion.form>
                    )}

                    {/* Registry Table */}
                    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-400 font-bold uppercase text-[9px] tracking-wider">
                            <th className="p-4">Assumption Node (Statement & Basis)</th>
                            <th className="p-4">Validation Signal</th>
                            <th className="p-4">Confidence</th>
                            <th className="p-4">PDI Status</th>
                            <th className="p-4 text-right">Operations</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-150">
                          {assumptions.map((a, idx) => (
                            <tr key={a.id} className="hover:bg-slate-50/50 transition-colors">
                              <td className="p-4 space-y-1 max-w-[320px]">
                                <span className="font-bold text-slate-900 block leading-normal">{a.statement}</span>
                                <span className="text-[10px] text-slate-400 block leading-normal">
                                  <strong className="text-slate-500">Basis:</strong> {a.evidenceBasis}
                                </span>
                                <div className="flex gap-2 text-[9px] font-mono text-slate-400 pt-1">
                                  <span>Owner: {a.owner}</span>
                                  <span>•</span>
                                  <span>Reviewed: {a.lastReviewed}</span>
                                </div>
                              </td>
                              <td className="p-4 text-slate-650 max-w-[220px] leading-relaxed">{a.signal}</td>
                              <td className="p-4">
                                <div className="flex items-center gap-1.5">
                                  <div className="w-12 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                    <div className="bg-purple-600 h-full" style={{ width: `${a.confidence}%` }}></div>
                                  </div>
                                  <span className="font-bold font-mono text-slate-700 text-[10px]">{a.confidence}%</span>
                                </div>
                              </td>
                              <td className="p-4">
                                <span className={`text-[9px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                                  a.status === 'Validated' 
                                    ? 'bg-green-50 text-green-700 border border-green-150' 
                                    : a.status === 'Expiring' 
                                      ? 'bg-amber-50 text-amber-700 border border-amber-150 animate-pulse'
                                      : a.status === 'Invalidated' 
                                        ? 'bg-red-50 text-red-700 border border-red-150'
                                        : 'bg-slate-50 text-slate-500 border border-slate-200'
                                }`}>
                                  {a.status}
                                </span>
                              </td>
                              <td className="p-4 text-right space-y-1">
                                {a.status === 'Unreviewed' || a.status === 'Expiring' ? (
                                  <div className="flex flex-col sm:flex-row gap-1 justify-end">
                                    <button
                                      onClick={() => handleVerifyAssumption(a.id, 'Validated')}
                                      className="px-2 py-1 bg-green-500 hover:bg-green-600 text-white rounded text-[9px] font-bold uppercase tracking-wider flex items-center justify-center gap-0.5"
                                      title="Confirm validated evidence"
                                    >
                                      <Check className="w-3 h-3" /> Validate
                                    </button>
                                    <button
                                      onClick={() => handleVerifyAssumption(a.id, 'Invalidated')}
                                      className="px-2 py-1 bg-red-500 hover:bg-red-600 text-white rounded text-[9px] font-bold uppercase tracking-wider flex items-center justify-center gap-0.5"
                                      title="Flag as invalidated"
                                    >
                                      <Trash2 className="w-3 h-3" /> Invalidate
                                    </button>
                                  </div>
                                ) : (
                                  <span className="text-[10px] text-slate-400 font-mono">Verified Node</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Section 5 Table explaining bounds */}
                    <div className="bg-slate-100 p-5 rounded-xl border border-slate-250 space-y-2">
                      <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                        <ShieldAlert className="w-4 h-4 text-purple-600" /> Human-in-the-loop Trust Boundary
                      </h4>
                      <p className="text-[11px] text-slate-500 leading-relaxed">
                        PDI is strictly designed as an <strong>evidence surface, not a decision engine</strong>. Automated updates require explicit PM confirmation before being persisted to your Neo4j database graph.
                      </p>
                    </div>
                  </div>
                )}

                {/* VIEW 3: PROACTIVE SIGNAL FEED (PROACTIVE MONITORING) */}
                {currentView === 'monitoring' && (
                  <div className="space-y-6">
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                      <h2 className="text-lg font-bold text-slate-905 flex items-center gap-2">
                        <Flame className="w-5 h-5 text-purple-600 shrink-0" />
                        Signal Feed (Proactive Monitors)
                      </h2>
                      <p className="text-xs text-slate-500 leading-normal mt-0.5">
                        Continuous background evaluation of the company memory graph against conflict, expiry, and duplication rules.
                      </p>
                    </div>

                    <div className="space-y-3">
                      {notifications.map((n) => (
                        <div 
                          key={n.id} 
                          className={`p-5 rounded-2xl border bg-white shadow-sm flex flex-col sm:flex-row sm:items-start justify-between gap-4 transition-all ${
                            n.severity === 'Critical' 
                              ? 'border-l-4 border-l-red-650' 
                              : n.severity === 'High' 
                                ? 'border-l-4 border-l-amber-500' 
                                : 'border-l-4 border-l-purple-500'
                          }`}
                        >
                          <div className="space-y-1.5 flex-1">
                            <div className="flex items-center gap-2">
                              <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded font-mono ${
                                n.severity === 'Critical' 
                                  ? 'bg-red-50 text-red-700' 
                                  : 'bg-amber-50 text-amber-700'
                              }`}>
                                {n.severity} Priority
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">{n.timestamp}</span>
                            </div>
                            <h3 className="text-xs font-bold text-slate-950">{n.title}</h3>
                            <p className="text-xs text-slate-700 leading-relaxed">{n.message}</p>
                            <p className="text-[11px] text-slate-400 font-sans italic">{n.details}</p>
                          </div>

                          <div className="flex sm:flex-col gap-2 justify-end self-end sm:self-start">
                            <button
                              onClick={() => {
                                setNotifications(prev => prev.map(item => item.id === n.id ? { ...item, status: 'resolved' } : item).filter(item => item.status === 'active'));
                              }}
                              className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-[10px] font-bold uppercase tracking-wider whitespace-nowrap transition-all shadow-sm"
                            >
                              Resolve Signal
                            </button>
                          </div>
                        </div>
                      ))}

                      {notifications.filter(n => n.status === 'active').length === 0 && (
                        <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 border-dashed text-slate-500">
                          <CheckCircle className="w-8 h-8 text-green-500 mx-auto mb-2" />
                          <span className="text-xs font-bold">All ambient conflict rules fully resolved.</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* VIEW 4: SOURCE INTEGRATIONS STATUS */}
                {currentView === 'integrations' && (
                  <div className="space-y-6">
                    <div className="bg-white p-6 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
                      <div>
                        <h2 className="text-lg font-bold text-slate-950 flex items-center gap-2">
                          <Layers className="w-5 h-5 text-purple-600" />
                          Ingestion Connector Manager
                        </h2>
                        <p className="text-xs text-slate-500 leading-normal mt-0.5">
                          Configure schedules and view synch freshness indicators for connected discovery stack tools.
                        </p>
                      </div>
                      <button
                        onClick={handleSimulateFullIngestion}
                        className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-sm"
                      >
                        Trigger Full Synch
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      {integrations.map((item) => (
                        <div 
                          key={item.id} 
                          className={`p-5 rounded-2xl border bg-white shadow-sm flex flex-col justify-between transition-all ${
                            item.status === 'connected' ? 'border-purple-100 hover:border-purple-300' : 'border-slate-200 bg-slate-50/50'
                          }`}
                        >
                          <div className="space-y-3">
                            <div className="flex justify-between items-start">
                              <span className="text-xs font-extrabold text-slate-900 leading-tight">{item.name}</span>
                              <span className={`w-2.5 h-2.5 rounded-full ${
                                item.status === 'connected' ? 'bg-green-500' : 'bg-slate-350'
                              }`} />
                            </div>
                            
                            <div className="font-mono text-[10px] text-slate-400 space-y-1">
                              <div>Freshness: {item.syncedAt}</div>
                              <div>Ingested Nodes: <strong className="text-slate-700">{item.count}</strong></div>
                              <div>Type: {item.category.toUpperCase()}</div>
                            </div>
                          </div>

                          <button
                            onClick={() => {
                              setIntegrations(prev => prev.map(curr => {
                                if (curr.id === item.id) {
                                  const toggled = curr.status === 'connected' ? 'disconnected' : 'connected';
                                  return {
                                    ...curr,
                                    status: toggled,
                                    syncedAt: toggled === 'connected' ? 'Just now' : 'Never',
                                    count: toggled === 'connected' ? 24 : 0
                                  };
                                }
                                return curr;
                              }));
                            }}
                            className={`w-full mt-4 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider border transition-all ${
                              item.status === 'connected' 
                                ? 'bg-red-50 border-red-100 text-red-600 hover:bg-red-100/50' 
                                : 'bg-purple-50 border-purple-100 text-purple-700 hover:bg-purple-100/50'
                            }`}
                          >
                            {item.status === 'connected' ? 'Disconnect' : 'Connect Tool'}
                          </button>
                        </div>
                      ))}
                    </div>

                    <div className="bg-white p-5 rounded-xl border border-slate-200 text-xs text-slate-500 leading-normal">
                      <strong className="text-slate-800">Note regarding Slack, Zoom, and Miro:</strong> Optical character recognition (OCR) and transcripts from Miro SVG and Zoom meetings are chunked dynamically into 400-600 token boundaries before indexing.
                    </div>
                  </div>
                )}

              </motion.div>
            )}

          </AnimatePresence>
        </main>

        {/* ========================================================= */}
        {/* RIGHT PANEL: CITATIONS & SOURCE ANALYSIS (Col Span: 3)    */}
        {/* ========================================================= */}
        {currentView === 'briefing' && showSourceSidebar && (
          <aside id="right-panel-ai" className="lg:col-span-3 bg-white p-6 flex flex-col gap-6 overflow-y-auto max-h-[calc(100vh-65px)] border-l border-slate-200">
            <div>
              <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-400 mb-1">Citations & Sources</h2>
              <p className="text-[11px] text-slate-500 leading-normal">Every synthesized claim is backed by transparent provenance in under three seconds.</p>
            </div>

            <div className="h-px bg-slate-100"></div>

            {/* In-Depth Selected Artifact Card */}
            {selectedArtifactId && (
              <div className="p-4 bg-purple-50/50 border border-purple-200 rounded-xl space-y-2.5">
                <div className="flex justify-between items-center text-[9px] font-mono text-purple-700 font-bold uppercase">
                  <span>Inspecting Node [{selectedArtifactId}]</span>
                  <button onClick={() => setSelectedArtifactId(null)} className="hover:underline">Clear</button>
                </div>
                {SAMPLE_CITED_ARTIFACTS.filter(a => a.id === selectedArtifactId).map((art) => (
                  <div key={art.id} className="space-y-1.5">
                    <h4 className="text-xs font-bold text-slate-950 leading-snug">{art.title}</h4>
                    <div className="text-[10px] text-slate-500 font-mono">
                      <div>Author: {art.author}</div>
                      <div>Date: {art.date}</div>
                      <div>Engine Match: {art.confidence * 100}%</div>
                    </div>
                    <a 
                      href={art.url} 
                      target="_blank" 
                      referrerPolicy="no-referrer"
                      className="text-[10px] text-purple-600 font-bold flex items-center gap-1 hover:underline"
                    >
                      Open in {art.source} <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                ))}
              </div>
            )}

            {/* Cited Source List */}
            <div className="space-y-3.5">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Grounding Artifacts ({SAMPLE_CITED_ARTIFACTS.length})</span>
              <div className="space-y-2.5">
                {SAMPLE_CITED_ARTIFACTS.map((art) => (
                  <div 
                    key={art.id} 
                    onClick={() => setSelectedArtifactId(art.id)}
                    className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                      selectedArtifactId === art.id 
                        ? 'border-purple-600 bg-purple-50/20' 
                        : 'border-slate-150 bg-slate-50 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-[9px] font-bold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded font-mono shrink-0">
                        [{art.id}] {art.source}
                      </span>
                      <span className="text-[9px] font-mono font-bold text-slate-400">{art.confidence * 100}% relevance</span>
                    </div>
                    <h4 className="text-xs font-bold text-slate-900 mt-2 truncate">{art.title}</h4>
                    <p className="text-[9px] text-slate-500 mt-0.5">{art.date} · {art.author}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Radial Viability Score */}
            {result && (
              <div className="text-center bg-slate-50/70 border border-slate-100 p-5 rounded-2xl flex flex-col items-center mt-auto">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-3">Initiative Viability</span>
                <div className="relative w-24 h-24 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="40" stroke="#F1F5F9" strokeWidth="8" fill="transparent" />
                    <circle cx="50" cy="50" r="40" stroke="#9333EA" strokeWidth="8" fill="transparent" strokeDasharray="251.2" strokeDashoffset={251.2 - (251.2 * result.score) / 100} className="transition-all duration-1000 ease-out" />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-2xl font-extrabold text-slate-900 font-mono">{result.score}%</span>
                    <span className="text-[8px] text-purple-600 font-bold uppercase tracking-wider">Viable</span>
                  </div>
                </div>
              </div>
            )}
          </aside>
        )}

      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowRight, 
  Sparkles, 
  AlertCircle, 
  TrendingUp, 
  Users, 
  CheckCircle,
  HelpCircle,
  Activity,
  ArrowDown,
  Database,
  Layers,
  Clock,
  Briefcase,
  ExternalLink,
  Lock,
  ChevronDown,
  FileText,
  Search,
  MessageSquare
} from 'lucide-react';

interface LandingProps {
  onNavigateToApp: () => void;
}

export default function LandingPage({ onNavigateToApp }: LandingProps) {
  const [selectedWorkaround, setSelectedWorkaround] = useState<number>(0);
  const [selectedStory, setSelectedStory] = useState<number>(0);

  const stats = [
    { value: "10/10", label: "Insights Lost", desc: "PMs confirm insights are captured but cannot be found later" },
    { value: "95%", label: "Insufficient Evidence", desc: "Admit decisions are made without sufficient evidence at least sometimes" },
    { value: "70%", label: "Retrieval Difficulty", desc: "Rate finding past research as difficult or very difficult" },
    { value: "50%", label: "Frequent Loss", desc: "Report losing valuable customer insights frequently" }
  ];

  const quotes = [
    {
      text: "I know we have answers to some of the current discovery problems somewhere. I just don't know where.",
      author: "Senior PM",
      company: "FinTech Scale-up, 450 employees"
    },
    {
      text: "We tell ourselves we are evidence-driven. Yet roadmap discussions still rely heavily on who speaks most confidently.",
      author: "VP of Product",
      company: "Enterprise B2B SaaS, 1,200 employees"
    },
    {
      text: "Knowledge disappears faster than we admit. We had a PM leave last year and six months later another team re-ran customer interviews on a problem he had already researched.",
      author: "Senior PM",
      company: "FinTech Organization"
    },
    {
      text: "I can find what decision was made. Finding why is another story entirely.",
      author: "Product Operations Manager",
      company: "HealthTech, 900 employees"
    }
  ];

  const workarounds = [
    {
      name: "Ask on Slack",
      works: "Fastest path to context — leverages human memory.",
      fails: "Doesn't scale; breaks when the person leaves; produces answers with no evidence trail.",
      badge: "Incomplete"
    },
    {
      name: "Search the Repository",
      works: "Consult Dovetail, Confluence, or Notion for prior work.",
      fails: "Search fails for non-obvious queries; research is never connected to the decisions it informed.",
      badge: "Siloed"
    },
    {
      name: "Run New Interviews",
      works: "Treat every question as new rather than risk missing prior work.",
      fails: "Incurs the full 'discovery tax' — same problem researched twice at full cost.",
      badge: "Extremely Wasteful"
    },
    {
      name: "Verbal Knowledge Transfer",
      works: "Handoff meetings and Slack DMs when a PM transitions.",
      fails: "Incomplete, unreliable, and produces no persistent or connected record.",
      badge: "Unreliable"
    },
    {
      name: "Consult ChatGPT",
      works: "Use general-purpose AI to answer discovery questions.",
      fails: "Draws on generic knowledge, not the organization's own accumulated context.",
      badge: "Decontextualized"
    },
    {
      name: "Maintain a Decision Log",
      works: "Write decisions into Notion or Confluence as they happen.",
      fails: "Pages are consulted once, if at all; no connection between the decision and the evidence behind it.",
      badge: "Static"
    }
  ];

  const stories = [
    {
      title: "The $400,000 Feature Nobody Needed",
      problem: "A SaaS team spent eight months building an advanced reporting dashboard, convinced of high demand by sales notes.",
      ignored: "Nine months earlier, a different PM completed 23 customer interviews proving the real problem was data accuracy, not reporting. But the original PM had left, and the notes sat buried in a Dovetail archive.",
      impact: "8 months of engineering effort wasted, $400,000 in development cost, and near-zero adoption after launch.",
      fix: "PDI would have surfaced the prior research, the existing assumption set, and the contradictory evidence before the roadmap decision was approved."
    },
    {
      title: "The Experiment That Had Already Failed",
      problem: "A PLG company spent six weeks designing, developing, and testing an onboarding experiment to improve activation.",
      ignored: "During the retro, a team member discovered a nearly identical experiment had been run and failed 18 months earlier. The results existed in a Confluence archive that was practically invisible.",
      impact: "6 weeks of engineering and product time wasted, duplicate learning, and team morale decline.",
      fix: "Before experiment creation, PDI would have surfaced similar prior experiments, their outcomes, and related customer feedback."
    },
    {
      title: "The Reorganization That Erased Product Memory",
      problem: "A 700-person company restructured. Three PMs moved areas and two departed, leaving a few handoff docs behind.",
      ignored: "Within four months, the new teams challenged and reopened several standing roadmap assumptions because no one could explain why they existed.",
      impact: "Three months of team delay, lost momentum on active initiatives, and severe executive frustration.",
      fix: "Every decision and assumption retains its original evidence base and outcome history — accessible independently of the people who originally built it."
    }
  ];

  const comparisons = [
    { tool: "Productboard", solves: "Feedback aggregation → roadmap prioritization", broken: "Insights don't connect to decisions; AI is rigid and non-contextual" },
    { tool: "Dovetail", solves: "Qualitative research archive", broken: "Research stays siloed; never reaches the decision-making workflow" },
    { tool: "Notion AI / Confluence AI", solves: "General-purpose knowledge search with AI overlay", broken: "Not purpose-built for product discovery; doesn't model discovery-specific relationships" },
    { tool: "Glean / Guru", solves: "Cross-tool semantic search", broken: "Retrieval only; does not model relationships between artifacts and decisions; no proactive conflict detection" },
    { tool: "PDI Platform", solves: "Organizational memory layer: connects research → assumptions → decisions → outcomes", broken: "The gap nobody else is filling", highlight: true }
  ];

  const testimonials = [
    {
      quote: "I asked the platform what we know about why customers drop off during onboarding. In forty seconds I had a synthesis linking three interview cycles, a Productboard feedback cluster, and the decision record from Q1 — with the assumptions that were active at the time and their current evidence status. That used to be a two-week research sprint.",
      author: "Director of Product",
      company: "Series B SaaS (180 employees)",
      avatarColor: "bg-indigo-100 text-indigo-700",
      avatarInitials: "DP"
    },
    {
      quote: "We had a PM leave last month. The new person was up to speed in four days. Not four months. Four days.",
      author: "Chief Product Officer (CPO)",
      company: "Enterprise FinTech",
      avatarColor: "bg-purple-100 text-purple-700",
      avatarInitials: "CP"
    },
    {
      quote: "We almost ran an experiment we'd already run. The platform flagged it before we scoped it. We would never have known.",
      author: "Head of Growth",
      company: "SaaS Scaleup",
      avatarColor: "bg-emerald-100 text-emerald-700",
      avatarInitials: "HG"
    },
    {
      quote: "I can finally answer the question our CPO asks every quarter: what are our highest-confidence strategic assumptions, and where are our evidence gaps? I used to not have a real answer. Now I do.",
      author: "Lead Product Manager",
      company: "HealthTech Platform",
      avatarColor: "bg-amber-100 text-amber-700",
      avatarInitials: "LM"
    }
  ];

  const pricingPlans = [
    {
      tier: "Team / Mid-Market",
      price: "$300 - $800",
      period: "month",
      audience: "Series A–C teams (50–300 employees) looking to secure institutional memory",
      features: [
        "Up to 10 product workspace seats",
        "Slack, Notion, and Dovetail integrations",
        "Basic RAG search & attribution",
        "Active Assumption Register UI",
        "Hourly incremental ingestion sync"
      ]
    },
    {
      tier: "Departmental / Growth",
      price: "$800 - $2,000",
      period: "month",
      popular: true,
      audience: "Growth-stage SaaS (300–1,200 employees) managing multiple silos",
      features: [
        "Unlimited seats for a single department",
        "All 8 integrations (Miro, Jira, Linear, Confluence)",
        "Advanced Hybrid Search (BM25 + RRF)",
        "Full Neo4j Knowledge Graph Construction",
        "Proactive Monitoring Feed (Conflicts, Expiries)"
      ]
    },
    {
      tier: "Enterprise / Private",
      price: "$2,000+",
      period: "month",
      audience: "Large enterprise requiring private deployments and strict compliance",
      features: [
        "100% Data residency guarantee",
        "Deploy private models (Llama 3.3, Mistral via Ollama)",
        "No third-party AI API routing",
        "SOC 2 Type II controls & compliance",
        "Dedicated onboarding & data archaeology"
      ]
    }
  ];

  return (
    <div className="bg-slate-50 min-h-screen font-sans text-slate-900 selection:bg-purple-100 selection:text-purple-900">
      {/* Navigation */}
      <header id="landing-header" className="border-b border-slate-200 py-4 px-6 md:px-12 flex justify-between items-center bg-white sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-purple-600 flex items-center justify-center shadow-sm">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-sans font-extrabold tracking-tight text-lg text-slate-900 flex items-center gap-1.5">
              PDI <span className="text-xs font-semibold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-100 uppercase">AI-Native</span>
            </span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <a 
            href="#workarounds" 
            className="hidden md:flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-purple-700 bg-purple-50/50 hover:bg-purple-50 border border-purple-200/60 px-3 py-1.5 rounded-full transition-all shadow-sm"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
            The Discovery Tax
          </a>
          <a 
            href="#stories" 
            className="hidden md:flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-red-700 bg-red-50/30 hover:bg-red-50 border border-red-200/40 px-3 py-1.5 rounded-full transition-all shadow-sm"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
            Failure Stories
          </a>
          <a 
            href="#testimonials" 
            className="hidden md:flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-indigo-700 bg-indigo-50/30 hover:bg-indigo-50 border border-indigo-200/40 px-3 py-1.5 rounded-full transition-all shadow-sm"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
            User Feedback
          </a>
          <a 
            href="#pricing" 
            className="hidden md:flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-emerald-700 bg-emerald-50/30 hover:bg-emerald-50 border border-emerald-200/40 px-3 py-1.5 rounded-full transition-all shadow-sm"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            Pricing Signals
          </a>
          <button 
            id="nav-cta-btn"
            onClick={onNavigateToApp} 
            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-lg transition-all shadow-sm flex items-center gap-1.5 uppercase tracking-wide"
          >
            Launch Console <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* 1. HERO SECTION */}
      <section id="hero-section" className="py-20 md:py-32 px-6 max-w-6xl mx-auto text-center relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-purple-50 rounded-full blur-3xl opacity-40 -z-10"></div>
        
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-50 border border-purple-100 rounded-full text-purple-700 text-[10px] font-bold uppercase tracking-wider mb-8"
        >
          <Sparkles className="w-3.5 h-3.5" /> Organizational Memory Layer
        </motion.div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-4xl md:text-6xl font-extrabold tracking-tight text-slate-950 leading-[1.1] mb-8 max-w-4xl mx-auto font-sans"
        >
          Product team's discovery knowledge <span className="text-purple-600">compounds</span> instead of disappearing.
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-sm md:text-base text-slate-600 max-w-3xl mx-auto mb-12 leading-relaxed"
        >
          <strong>Product Discovery Intelligence (PDI)</strong> is the first B2B SaaS platform built to automatically connect customer research, product assumptions, and roadmap decisions. Designed specifically for Series A–C SaaS teams to eliminate the silent <strong>$400,000 discovery tax</strong>.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-col sm:flex-row justify-center items-center gap-4"
        >
          <button 
            id="hero-primary-cta"
            onClick={onNavigateToApp}
            className="w-full sm:w-auto px-7 py-3.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-sm uppercase tracking-wider rounded-xl transition-all shadow-md shadow-purple-200 flex items-center justify-center gap-2 group"
          >
            Launch PDI Console 
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
          <a 
            href="#stories"
            className="w-full sm:w-auto px-7 py-3.5 bg-white hover:bg-slate-50 text-slate-700 font-bold text-sm uppercase tracking-wider rounded-xl border border-slate-200 transition-all flex items-center justify-center gap-1"
          >
            Read Failure Case Studies <ArrowDown className="w-4 h-4" />
          </a>
        </motion.div>
      </section>

      {/* 2. RESEARCH STATISTICS GRID */}
      <section id="stats-section" className="py-16 bg-white border-y border-slate-200 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-xs font-extrabold uppercase tracking-widest text-slate-400 mb-2">Validated User Research</h2>
            <p className="text-lg font-bold text-slate-950">A comprehensive synthesis from 10 in-depth qualitative interviews & 20 survey responses across B2B SaaS, FinTech, and HealthTech.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {stats.map((st, idx) => (
              <div key={idx} className="p-6 bg-slate-50 rounded-2xl border border-slate-150 relative">
                <span className="text-4xl font-extrabold text-purple-600 font-mono block">{st.value}</span>
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wide block mt-2">{st.label}</span>
                <p className="text-xs text-slate-500 mt-1 leading-normal">{st.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. REAL PARTICIPANT QUOTES SLIDER */}
      <section className="py-20 bg-slate-50 px-6 border-b border-slate-250">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-purple-600 font-extrabold uppercase tracking-widest text-[10px]">Voices from the Field</span>
            <h2 className="text-2xl font-bold text-slate-900 mt-1">Phrases that Define the Discovery Problem</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {quotes.map((q, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                <p className="text-xs font-medium text-slate-700 italic leading-relaxed">
                  &ldquo;{q.text}&rdquo;
                </p>
                <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between items-center text-[10px]">
                  <span className="font-bold text-slate-900">{q.author}</span>
                  <span className="text-slate-400 font-mono">{q.company}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. WORKAROUNDS & THE DISCOVERY TAX */}
      <section id="workarounds" className="py-24 bg-white px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-12 gap-12 items-center">
            
            {/* Left side column info */}
            <div className="md:col-span-5 space-y-6">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-purple-50 border border-purple-200 rounded-full text-purple-700 text-[10px] font-extrabold uppercase tracking-widest">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-ping"></span>
                The Discovery Tax
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight text-slate-950">How product teams currently solve this (And why they fail)</h2>
              <p className="text-xs text-slate-500 leading-relaxed">
                There is no single workaround. Teams patch together a fragmented series of compensating behaviors that fail to build organizational memory. They transfer info in the moment, but nothing persists or compounds.
              </p>
              
              <div className="space-y-2 mt-4">
                {workarounds.map((w, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedWorkaround(idx)}
                    className={`w-full text-left p-3 rounded-xl border text-xs font-semibold flex justify-between items-center transition-all ${
                      selectedWorkaround === idx 
                        ? 'bg-purple-50/50 border-purple-500 text-purple-900' 
                        : 'bg-white border-slate-150 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>{w.name}</span>
                    <span className={`text-[9px] px-2 py-0.5 rounded-full font-mono ${
                      selectedWorkaround === idx ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-500'
                    }`}>{w.badge}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Right side detailed pane */}
            <div className="md:col-span-7 bg-slate-50 p-8 rounded-2xl border border-slate-200">
              <div className="space-y-6">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">Detailed Workaround Analysis</span>
                  <h3 className="text-xl font-bold text-slate-950 mt-1">{workarounds[selectedWorkaround].name}</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="p-4 bg-white rounded-xl border border-slate-150">
                    <span className="text-[9px] font-bold text-purple-700 block uppercase tracking-wider">How it works</span>
                    <p className="text-xs text-slate-700 mt-1 leading-relaxed">{workarounds[selectedWorkaround].works}</p>
                  </div>

                  <div className="p-4 bg-red-50/30 border border-red-100 rounded-xl">
                    <span className="text-[9px] font-bold text-red-700 block uppercase tracking-wider">Why it fails</span>
                    <p className="text-xs text-slate-700 mt-1 leading-relaxed">{workarounds[selectedWorkaround].fails}</p>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-200 flex justify-between items-center">
                  <span className="text-xs text-slate-500">Drove the development of PDI Memory layer</span>
                  <button 
                    onClick={onNavigateToApp} 
                    className="text-xs text-purple-600 font-bold hover:underline flex items-center gap-1"
                  >
                    Test the Platform <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 5. SUCCESS/FAILURE HIGH SIGNAL STORIES */}
      <section id="stories" className="py-24 bg-slate-50 border-y border-slate-200 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-50 border border-red-200 rounded-full text-red-700 text-[10px] font-extrabold uppercase tracking-widest mb-2">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
              Failure Stories
            </span>
            <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 mt-1">Wasted engineering in the wild</h2>
            <p className="text-slate-500 text-xs mt-2">These are three actual failure stories from research interviews, illustrating the heavy tax teams pay without institutional memory.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {stories.map((st, idx) => (
              <div 
                key={idx} 
                className="bg-white p-6 rounded-2xl border border-red-100 hover:border-red-350 shadow-sm hover:shadow-md flex flex-col justify-between transition-all duration-300"
              >
                <div className="space-y-4">
                  <div className="w-8 h-8 rounded-full bg-red-50 flex items-center justify-center text-red-600 font-bold text-xs">
                    {idx + 1}
                  </div>
                  <h3 className="text-sm font-bold text-slate-950 leading-snug">{st.title}</h3>
                  <p className="text-[11px] text-slate-600 leading-relaxed">{st.problem}</p>
                  
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-150 text-[10px] text-slate-500 leading-relaxed">
                    <strong className="text-slate-800">The Hidden Truth:</strong> {st.ignored}
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 space-y-2">
                  <div className="text-[10px] text-red-700 bg-red-50 px-2 py-1 rounded-md font-semibold">
                    <strong>Impact:</strong> {st.impact}
                  </div>
                  <div className="text-[10px] text-purple-700 bg-purple-50 px-2 py-1 rounded-md font-semibold">
                    <strong>How PDI Fixes:</strong> {st.fix}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. COMPETITIVE LANDSCAPE SUMMARY */}
      <section className="py-24 bg-white px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-purple-600 font-extrabold uppercase tracking-widest text-[10px]">Appendix Summary</span>
            <h2 className="text-2xl font-bold text-slate-950 mt-1">The Point Tool Problem vs. PDI</h2>
            <p className="text-xs text-slate-400 mt-1">Existing point tools solve narrow, well-defined problems. None of them solve the connective layer.</p>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-slate-50/50">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-100 text-slate-600 font-bold uppercase text-[9px] tracking-wider">
                  <th className="p-4">Tool Class / Competitor</th>
                  <th className="p-4">What it solves</th>
                  <th className="p-4">What it leaves broken / Gaps</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-150">
                {comparisons.map((c, idx) => (
                  <tr 
                    key={idx} 
                    className={`transition-colors ${c.highlight ? 'bg-purple-50/50 hover:bg-purple-50 font-medium' : 'bg-white hover:bg-slate-50'}`}
                  >
                    <td className="p-4 font-bold text-slate-950 flex items-center gap-2">
                      {c.highlight && <Sparkles className="w-3.5 h-3.5 text-purple-600 shrink-0" />}
                      {c.tool}
                    </td>
                    <td className="p-4 text-slate-650">{c.solves}</td>
                    <td className={`p-4 ${c.highlight ? 'text-purple-700 font-bold' : 'text-slate-500'}`}>{c.broken}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* 6.5. SIX MONTHS WITH THE PLATFORM (TESTIMONIALS) */}
      <section id="testimonials" className="py-24 bg-slate-50 border-t border-slate-200 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-purple-50 border border-purple-200 rounded-full text-purple-700 text-[10px] font-extrabold uppercase tracking-widest mb-2">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-pulse"></span>
              6 Months With The Platform
            </span>
            <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 mt-1">What our users say</h2>
            <p className="text-slate-500 text-xs mt-2">
              Actual feedback from B2B product organizations after integrating PDI as their shared discovery memory layer.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {testimonials.map((t, idx) => (
              <div 
                key={idx} 
                className="bg-white p-6 rounded-2xl border border-slate-200/85 shadow-sm hover:shadow-md hover:border-purple-300 transition-all duration-300 flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="text-purple-300 select-none text-4xl font-serif leading-none">&ldquo;</div>
                  <p className="text-xs font-medium text-slate-700 leading-relaxed -mt-3">
                    {t.quote}
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-100 flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full ${t.avatarColor} flex items-center justify-center text-[10px] font-extrabold tracking-wider shrink-0 shadow-inner`}>
                    {t.avatarInitials}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-[11px] font-bold text-slate-950 truncate leading-none">{t.author}</h4>
                    <span className="text-[9px] text-slate-400 font-mono block mt-1 truncate">{t.company}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. PRICING BASED ON SURVEY SIGNALS */}
      <section id="pricing" className="py-24 bg-slate-50 px-6 border-t border-slate-200">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-full text-emerald-700 text-[10px] font-extrabold uppercase tracking-widest mb-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              Pricing Signals
            </span>
            <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 mt-1">Direct budget-aligned plans</h2>
            <p className="text-slate-500 text-xs mt-2">
              Our pricing is derived directly from user survey signals: B2B organizations budget in terms of duplicate research avoided, onboarding acceleration, and saved engineer months.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((p, idx) => (
              <div 
                key={idx} 
                className={`bg-white rounded-2xl border p-8 flex flex-col justify-between shadow-sm relative ${
                  p.popular ? 'border-purple-500 ring-2 ring-purple-100' : 'border-slate-200'
                }`}
              >
                {p.popular && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-purple-600 text-white font-extrabold text-[9px] uppercase tracking-wider px-3 py-1 rounded-full shadow-sm">
                    Most Popular for SaaS
                  </span>
                )}
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-bold text-slate-950 uppercase tracking-wide">{p.tier}</h3>
                    <div className="mt-4 flex items-baseline gap-1">
                      <span className="text-3xl font-extrabold text-slate-950 font-mono">{p.price}</span>
                      <span className="text-xs text-slate-400 font-mono">/ {p.period}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-2 min-h-[32px] leading-relaxed">{p.audience}</p>
                  </div>

                  <div className="h-px bg-slate-100"></div>

                  <ul className="space-y-2.5 text-xs">
                    {p.features.map((f, i) => (
                      <li key={i} className="flex gap-2.5 items-start">
                        <CheckCircle className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                        <span className="text-slate-700 leading-normal">{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button 
                  onClick={onNavigateToApp}
                  className={`w-full mt-8 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all ${
                    p.popular 
                      ? 'bg-purple-600 hover:bg-purple-700 text-white shadow-md shadow-purple-100' 
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-850'
                  }`}
                >
                  Configure Ingestions
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. CTA FOOTER */}
      <section className="py-24 px-6 bg-white border-t border-slate-200 text-center relative overflow-hidden">
        <div className="max-w-3xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight text-slate-950 mb-6 font-sans">
            Ready to secure your company's memory?
          </h2>
          <p className="text-slate-500 text-xs mb-8 max-w-lg mx-auto leading-relaxed">
            Connect your existing discovery tools in 15 minutes, populate your assumption registers, and let AI monitor evidence gaps and conflicts dynamically.
          </p>
          <button 
            id="footer-cta-btn"
            onClick={onNavigateToApp}
            className="px-8 py-4 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg hover:shadow-purple-100 flex items-center justify-center gap-2 mx-auto group"
          >
            Launch PDI Workspace Console
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>

      {/* Footer copyright */}
      <footer id="simple-footer" className="py-12 bg-slate-50 text-center text-xs text-slate-400 border-t border-slate-200">
        <p>&copy; {new Date().getFullYear()} Product Discovery Intelligence (PDI). All rights reserved. Underpinned by Neo4j & Reciprocal Rank Fusion.</p>
        <p className="mt-1 font-mono text-[9px] text-slate-350">Version 1.0 (June 2026) · Classification: Confidential</p>
      </footer>
    </div>
  );
}

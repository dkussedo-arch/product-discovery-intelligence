export interface MarketMetric {
  value: string;
  numberValue: number; // in Millions USD
  label: string;
  description: string;
}

export interface Competitor {
  name: string;
  marketShare: number; // percentage
  strengths: string[];
  weaknesses: string[];
  differentiator: string;
}

export interface SWOTData {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
}

export interface InterviewQuestion {
  question: string;
  objective: string;
  targetAudience: string;
  followUp: string[];
}

export interface ProductGap {
  area: string;
  description: string;
  opportunityLevel: 'High' | 'Medium' | 'Low';
}

export interface Recommendation {
  title: string;
  description: string;
  priority: 'High' | 'Medium' | 'Low';
  timeline: string;
}

export interface ProductValidationResult {
  productConcept: {
    name: string;
    description: string;
    audience: string;
    painPoints: string;
    industry: string;
  };
  score: number; // 0 - 100
  confidence: number; // 0 - 100
  marketSize: {
    tam: MarketMetric;
    sam: MarketMetric;
    som: MarketMetric;
  };
  swot: SWOTData;
  competitors: Competitor[];
  playbook: InterviewQuestion[];
  gaps: ProductGap[];
  recommendations: Recommendation[];
  summary: string;
}

export interface DiscoveryInput {
  name: string;
  description: string;
  audience: string;
  painPoints: string;
  industry: string;
}

// PDI specific domain models
export interface Assumption {
  id: string;
  statement: string; // "We believe [X]"
  evidenceBasis: string; // "because [evidence]"
  signal: string; // "We will know this is true if [signal]"
  status: 'Validated' | 'Expiring' | 'Invalidated' | 'Unreviewed';
  lastReviewed: string;
  owner: string;
  initiative: string;
  confidence: number;
}

export interface SignalNotification {
  id: string;
  triggerType: 'conflict' | 'expiry' | 'unconsulted' | 'gap' | 'duplicate';
  title: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  timestamp: string;
  message: string;
  details: string;
  status: 'active' | 'resolved' | 'dismissed';
}

export interface SourceIntegration {
  id: string;
  name: string;
  status: 'connected' | 'error' | 'disconnected';
  syncedAt: string;
  count: number;
  category: 'text' | 'conversational' | 'tabular' | 'visual';
}

// Default/mock product concepts to help user test quickly
export const TEMPLATE_PRODUCTS: { label: string; data: DiscoveryInput }[] = [
  {
    label: "Micro-SaaS Analytics (LiteMetrics)",
    data: {
      name: "LiteMetrics",
      description: "A privacy-first, zero-configuration analytics tool designed specifically for indie hackers and micro-SaaS builders with less than $10k MRR.",
      audience: "Indie Hackers, Solo Founders, and Micro-SaaS Owners",
      painPoints: "Google Analytics is too complex and heavy; cookie consent banners ruin UX; other alternatives like Fathom or Plausible are too expensive for side projects.",
      industry: "B2B SaaS / Web Analytics"
    }
  },
  {
    label: "AI Fitness Coach for Desk Workers",
    data: {
      name: "DeskActive",
      description: "An AI-powered posture and activity coach that uses a webcam to monitor posture, remind users of screen breaks, and guide them through 2-minute office-friendly stretches.",
      audience: "Remote Software Engineers, Digital Nomads, and Desk-bound Professionals",
      painPoints: "Chronic lower back pain; screen fatigue; forgetfulness to take standing or active breaks; expensive physical therapist bills.",
      industry: "Digital Health & Wellness"
    }
  },
  {
    label: "Local Organic Food Delivery Platform",
    data: {
      name: "SoilToTable",
      description: "A subscription-based micro-delivery network connecting local urban farms directly with households within a 5-mile radius, promising fresh harvest-to-door deliveries in under 4 hours.",
      audience: "Eco-conscious urban families and high-income health enthusiasts",
      painPoints: "Supermarket 'organic' food is often weeks old; local CSA boxes have zero customization; traditional delivery apps have massive service fees and carbon footprints.",
      industry: "FoodTech / Local Commerce"
    }
  }
];

